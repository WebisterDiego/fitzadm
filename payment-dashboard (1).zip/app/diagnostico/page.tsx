"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import DiagnosticTool from "@/components/diagnostic-tool"

export default function DiagnosticPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Verificar autenticação no localStorage
    const auth = localStorage.getItem("authenticated")

    if (auth !== "true") {
      router.push("/login")
    } else {
      setIsAuthenticated(true)
    }

    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  if (!isAuthenticated) {
    return null // Não renderiza nada enquanto redireciona
  }

  return (
    <div className="container mx-auto py-4 px-4">
      <div className="flex items-center mb-4">
        <Link href="/" className="mr-4">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-xl font-bold">Diagnóstico do Sistema</h1>
      </div>

      <div className="grid gap-4">
        <DiagnosticTool />
      </div>
    </div>
  )
}
