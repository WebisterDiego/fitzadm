"use client"

import Link from "next/link"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ExternalLink, CheckCircle, Share2, Copy, Check } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { createClient } from "@/utils/supabase/client"
import RefreshIndicator from "@/components/refresh-indicator"

export default function FinancePanel() {
  const params = useParams()
  const router = useRouter()
  const storeName = decodeURIComponent(params.store)
  const [orders, setOrders] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [copiedOrderId, setCopiedOrderId] = useState(null)
  const [expandedOrderId, setExpandedOrderId] = useState(null)
  const supabase = createClient()
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    // Verificar autenticação
    const checkAuth = async () => {
      const isAuthenticated = localStorage.getItem("authenticated") === "true"
      if (!isAuthenticated) {
        router.push("/login")
        return
      }

      // Carregar ordens desta loja
      loadOrders()
    }

    const loadOrders = async () => {
      setIsRefreshing(true)
      try {
        // Mostrar todas as ordens da loja, não apenas as que estão em processamento ou aguardando liberação
        const { data, error } = await supabase
          .from("orders")
          .select("*")
          .eq("store", storeName)
          .order("created_at", { ascending: false })

        if (error) throw error

        setOrders(data || [])
        setLastRefresh(new Date())
      } catch (error) {
        console.error("Erro ao carregar ordens:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar as ordens.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
        setIsRefreshing(false)
      }
    }

    checkAuth()

    // Configurar assinatura em tempo real para ordens
    const subscription = supabase
      .channel(`store-orders-${storeName}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "orders",
          filter: `store=eq.${storeName}`,
        },
        loadOrders,
      )
      .subscribe()

    // Atualizar dados a cada 5 segundos
    const refreshInterval = setInterval(() => {
      console.log("Atualizando dados do painel financeiro a cada 5 segundos")
      loadOrders()
    }, 5000)

    // Verificar ordens expiradas periodicamente
    const checkExpiredOrders = async () => {
      const now = new Date().toISOString()

      // Verificar se há ordens pendentes que já expiraram
      const { data: expiredOrders } = await supabase
        .from("orders")
        .select("id")
        .eq("status", "pending")
        .eq("store", storeName)
        .lt("expiration_time", now)

      // Se houver ordens expiradas, recarregar os dados
      if (expiredOrders && expiredOrders.length > 0) {
        loadOrders()
      }
    }

    // Configurar intervalo para verificar ordens expiradas
    const expirationInterval = setInterval(checkExpiredOrders, 20000) // A cada 20 segundos

    return () => {
      supabase.removeChannel(subscription)
      clearInterval(refreshInterval)
      clearInterval(expirationInterval)
    }
  }, [storeName, router, supabase])

  const handleReceiveClick = async (orderId) => {
    try {
      // Atualizar o status da ordem para "awaiting_release"
      const { error } = await supabase
        .from("orders")
        .update({
          status: "awaiting_release",
          status_text: "Aguardando Liberação",
          updated_at: new Date().toISOString(),
        })
        .eq("id", orderId)

      if (error) throw error

      // Atualizar ordens locais
      setOrders(
        orders.map((order) => {
          if (order.id === orderId) {
            return {
              ...order,
              status: "awaiting_release",
              status_text: "Aguardando Liberação",
              updated_at: new Date().toISOString(),
            }
          }
          return order
        }),
      )

      toast({
        title: "Pagamento recebido",
        description: "A ordem foi marcada como recebida e aguarda liberação da vendedora.",
      })
    } catch (error) {
      console.error("Erro ao atualizar ordem:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao atualizar a ordem.",
        variant: "destructive",
      })
    }
  }

  const copyOrderInfo = (order) => {
    // Verificar se a ordem está em um dos estados que permitem compartilhar informações
    const canShareInfo = ["awaiting_release", "processing", "released"].includes(order.status)

    if (canShareInfo) {
      // Formatar as informações da ordem para compartilhar
      let orderInfo =
        `*Informações da Ordem*\n\n` +
        `*ID do Cliente:* ${order.client_id}\n` +
        `*Nome do Cliente:* ${order.client_name}\n` +
        `*Nome da Vendedora:* ${order.seller_name}\n` +
        `*Nome da Loja:* ${order.store}\n` +
        `*Valor em Dólar Recebido:* $${Number.parseFloat(order.amount_usd).toFixed(2)}\n` +
        `*Status da Ordem:* ${order.status_text || getStatusText(order.status)}`

      // Adicionar notas se existirem
      if (order.notes && order.notes.trim()) {
        orderInfo += `\n\n*Notas:*\n${order.notes}`
      }

      // Copiar para a área de transferência
      navigator.clipboard.writeText(orderInfo)
      setCopiedOrderId(order.id)

      toast({
        title: "Informações copiadas",
        description: "As informações da ordem foram copiadas para a área de transferência.",
      })

      // Resetar o estado de copiado após 2 segundos
      setTimeout(() => setCopiedOrderId(null), 2000)
    } else {
      // Se a ordem ainda não foi processada, copiar o link como antes
      const shareUrl = `${window.location.origin}/order/${order.id}`
      navigator.clipboard.writeText(shareUrl)

      toast({
        title: "Link copiado",
        description: "O link para compartilhar foi copiado para a área de transferência.",
      })
    }
  }

  const toggleOrderExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId)
  }

  const getStatusText = (status) => {
    switch (status) {
      case "pending":
        return "Aguardando Pagamento"
      case "converting":
        return "Convertendo Dinheiro"
      case "processing":
        return "Processando Pagamento"
      case "awaiting_release":
        return "Aguardando Liberação"
      case "released":
        return "Pedido Liberado"
      case "expired":
        return "Pagamento Expirado"
      default:
        return "Aguardando Pagamento"
    }
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  return (
    <div className="container mx-auto py-4 px-4">
      <div className="mb-4">
        <div className="flex flex-col">
          <h1 className="text-xl font-bold">Painel Financeiro: {storeName}</h1>
          <RefreshIndicator lastRefresh={lastRefresh} isRefreshing={isRefreshing} />
        </div>
      </div>

      {orders.length === 0 ? (
        <Card>
          <CardContent className="flex items-center justify-center h-40">
            <p className="text-muted-foreground">Nenhuma ordem encontrada para esta loja.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {orders.map((order) => (
            <Card
              key={order.id}
              className={`overflow-hidden cursor-pointer ${
                order.status === "awaiting_release"
                  ? "border-blue-500"
                  : order.status === "released"
                    ? "border-green-500"
                    : order.status === "expired"
                      ? "border-red-500"
                      : ""
              }`}
              onClick={() => toggleOrderExpand(order.id)}
            >
              <CardContent className="p-3">
                {/* Cabeçalho compacto - sempre visível */}
                <div className="flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-medium text-sm">{order.client_id}</span>
                      <span className="font-medium text-sm">-</span>
                      <span className="font-medium text-sm">{order.client_name}</span>
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                      <Badge
                        variant={
                          order.status === "awaiting_release"
                            ? "default"
                            : order.status === "processing"
                              ? "primary"
                              : order.status === "released"
                                ? "success"
                                : order.status === "expired"
                                  ? "destructive"
                                  : "secondary"
                        }
                        className="text-xs"
                      >
                        {order.status_text || getStatusText(order.status)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(order.created_at).toLocaleDateString("pt-BR")}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">${Number.parseFloat(order.amount_usd).toFixed(2)}</p>
                    <p className="text-xs">R$ {Number.parseFloat(order.amount_brl).toFixed(2)}</p>
                  </div>
                </div>

                {/* Conteúdo expandido - visível apenas quando expandido */}
                {expandedOrderId === order.id && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-sm mb-3">
                      <p className="text-xs text-muted-foreground">Vendedora:</p>
                      <p className="font-medium text-sm">{order.seller_name}</p>
                    </div>

                    {order.notes && (
                      <div className="bg-gray-50 p-2 rounded-md mb-3 text-sm">
                        <p className="font-medium text-xs mb-1">Notas:</p>
                        {order.notes.split("\n").map((note, i) => (
                          <p key={i} className="text-sm">
                            {note}
                          </p>
                        ))}
                      </div>
                    )}

                    {order.txid && (
                      <div className="mb-3">
                        <a
                          href={`http://tronscan.org/#/transaction/${order.txid}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-blue-600 hover:underline inline-flex items-center"
                        >
                          Ver transação <ExternalLink className="h-3 w-3 ml-1" />
                        </a>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 mt-3">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 text-xs h-8"
                        onClick={(e) => {
                          e.stopPropagation()
                          copyOrderInfo(order)
                        }}
                      >
                        {copiedOrderId === order.id ? (
                          <>
                            <Check className="h-3 w-3 mr-1" /> Copiado
                          </>
                        ) : (
                          <>
                            {["awaiting_release", "processing", "released"].includes(order.status) ? (
                              <Copy className="h-3 w-3 mr-1" />
                            ) : (
                              <Share2 className="h-3 w-3 mr-1" />
                            )}
                            {["awaiting_release", "processing", "released"].includes(order.status)
                              ? "Copiar Informações"
                              : "Compartilhar Link"}
                          </>
                        )}
                      </Button>

                      <Link href={`/order/${order.id}`} className="flex-1" onClick={(e) => e.stopPropagation()}>
                        <Button variant="outline" size="sm" className="w-full text-xs h-8">
                          <ExternalLink className="h-3 w-3 mr-1" /> Ver
                        </Button>
                      </Link>

                      {order.status === "processing" && (
                        <Button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleReceiveClick(order.id)
                          }}
                          className="flex items-center text-xs h-8"
                          size="sm"
                        >
                          <CheckCircle className="h-3 w-3 mr-1" /> Confirmar
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Toaster />
    </div>
  )
}
