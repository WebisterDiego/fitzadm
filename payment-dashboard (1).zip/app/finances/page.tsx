"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, ExternalLink, Copy, Check } from "lucide-react"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { createClient } from "@/utils/supabase/client"

export default function FinancesList() {
  const [finances, setFinances] = useState([])
  const [copiedId, setCopiedId] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    // Verificar autenticação
    const checkAuth = async () => {
      const isAuthenticated = localStorage.getItem("authenticated") === "true"
      if (!isAuthenticated) {
        router.push("/login")
        return
      }

      // Carregar painéis financeiros
      loadFinances()
    }

    const loadFinances = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase.from("finances").select("*").order("created_at", { ascending: false })

        if (error) throw error

        setFinances(data || [])
      } catch (error) {
        console.error("Erro ao carregar painéis financeiros:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar os painéis financeiros.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()

    // Configurar assinatura em tempo real para painéis financeiros
    const subscription = supabase
      .channel("finances-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "finances" }, loadFinances)
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [router, supabase])

  const copyFinanceLink = (financeId) => {
    const finance = finances.find((f) => f.id === financeId)
    if (!finance) return

    const financeUrl = `${window.location.origin}/finance/${encodeURIComponent(finance.store)}`
    navigator.clipboard.writeText(financeUrl)
    setCopiedId(financeId)
    toast({
      title: "Link copiado",
      description: "O link do painel financeiro foi copiado para a área de transferência.",
    })
    setTimeout(() => setCopiedId(null), 2000)
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  return (
    <div className="container mx-auto py-4 px-4 max-w-3xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Link href="/" className="mr-4">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Painéis Financeiros</h1>
        </div>
      </div>

      {finances.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-40">
            <p className="text-muted-foreground mb-4">Nenhum painel financeiro encontrado.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {finances.map((finance) => (
            <Card key={finance.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="font-medium text-lg">Financeiro: {finance.store}</h2>
                    <p className="text-sm text-muted-foreground">
                      Criado em: {new Date(finance.created_at).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyFinanceLink(finance.id)}
                      className="flex items-center"
                    >
                      {copiedId === finance.id ? (
                        <>
                          <Check className="h-4 w-4 mr-1" /> Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4 mr-1" /> Copiar Link
                        </>
                      )}
                    </Button>
                    <Link href={`/finance/${encodeURIComponent(finance.store)}`}>
                      <Button size="sm" className="flex items-center">
                        <ExternalLink className="h-4 w-4 mr-1" /> Acessar Painel
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Toaster />
    </div>
  )
}
