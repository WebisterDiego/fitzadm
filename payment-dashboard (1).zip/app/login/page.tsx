"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock } from "lucide-react"
import { createClient } from "@/utils/supabase/client"

export default function Login() {
  const [pin, setPin] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    // Verificar se já está autenticado
    const isAuthenticated = localStorage.getItem("authenticated") === "true"
    if (isAuthenticated) {
      router.push("/")
    }
  }, [router])

  const handleLogin = async () => {
    setIsLoading(true)
    setError("")

    try {
      // Buscar o PIN de segurança do banco de dados
      const { data: securitySettings, error: fetchError } = await supabase
        .from("security_settings")
        .select("security_pin")
        .single()

      if (fetchError) {
        throw new Error("Erro ao buscar configurações de segurança")
      }

      const storedPin = securitySettings?.security_pin || "99668526"

      if (pin === storedPin) {
        // Usar localStorage para autenticação simples
        localStorage.setItem("authenticated", "true")
        router.push("/")
      } else {
        setError("PIN inválido. Tente novamente.")
      }
    } catch (error) {
      console.error("Erro de login:", error)
      setError("Ocorreu um erro ao fazer login. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl text-center">
            <div className="flex items-center justify-center gap-2">
              <Lock className="h-6 w-6" />
              Acesso ao Sistema
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Input
                id="pin"
                type="password"
                placeholder="Digite o PIN de acesso"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="text-center text-xl tracking-widest"
                maxLength={8}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleLogin()
                  }
                }}
              />
              {error && <p className="text-sm text-red-500 text-center">{error}</p>}
            </div>
            <Button className="w-full" onClick={handleLogin} disabled={pin.length < 8 || isLoading}>
              {isLoading ? "Entrando..." : "Entrar"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
