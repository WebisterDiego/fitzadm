"use client"

import { useEffect, useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clipboard, Check, AlertTriangle, Loader2 } from "lucide-react"
import { useParams } from "next/navigation"
import { createClient } from "@/utils/supabase/client"
import RefreshIndicator from "@/components/refresh-indicator"

export default function OrderPage() {
  const params = useParams()
  const orderId = params.id
  const [order, setOrder] = useState(null)
  const [copied, setCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [error, setError] = useState(null)
  const [expired, setExpired] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const timerRef = useRef(null)
  const refreshIntervalRef = useRef(null)
  const expirationHandledRef = useRef(false)
  const supabase = createClient()

  // Função para formatar o tempo restante
  const formatTimeLeft = () => {
    const minutes = Math.floor(timeLeft / 60)
    const seconds = timeLeft % 60
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }

  // Função para copiar o código de pagamento
  const copyPaymentCode = () => {
    if (order?.payment_code) {
      navigator.clipboard.writeText(order.payment_code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  // Função para iniciar o temporizador de expiração
  const startExpirationTimer = (seconds) => {
    // Limpar qualquer temporizador existente
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    // Iniciar novo temporizador
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        const newTime = prev - 1
        if (newTime <= 0) {
          clearInterval(timerRef.current)
          setExpired(true)
          updateOrderStatusToExpired()
          return 0
        }
        return newTime
      })
    }, 1000)
  }

  // Função para atualizar o status da ordem para expirado no banco de dados
  const updateOrderStatusToExpired = async () => {
    // Evitar múltiplas atualizações
    if (expirationHandledRef.current || !order || order.status !== "pending") return
    expirationHandledRef.current = true

    try {
      const { error } = await supabase
        .from("orders")
        .update({
          status: "expired",
          status_text: "Pagamento Expirado",
          updated_at: new Date().toISOString(),
        })
        .eq("id", orderId)
        .eq("status", "pending") // Garantir que só atualize se ainda estiver pendente

      if (error) throw error

      // Atualizar o estado local
      setOrder((prev) => {
        if (!prev) return null
        return {
          ...prev,
          status: "expired",
          status_text: "Pagamento Expirado",
          updated_at: new Date().toISOString(),
        }
      })
    } catch (error) {
      console.error("Erro ao atualizar status da ordem:", error)
    }
  }

  // Função para obter o texto do status
  const getStatusText = (status) => {
    switch (status) {
      case "pending":
        return "Aguardando Pagamento"
      case "converting":
        return "Convertendo Dinheiro"
      case "processing":
        return "Processando Pagamento"
      case "awaiting_release":
        return "Aguardando Liberação"
      case "released":
        return "Pedido Liberado"
      case "expired":
        return "Pagamento Expirado"
      default:
        return "Aguardando Pagamento"
    }
  }

  // Função para obter a variante do badge de status
  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "converting":
        return "warning"
      case "processing":
        return "primary"
      case "awaiting_release":
        return "default"
      case "released":
        return "success"
      case "expired":
        return "destructive"
      default:
        return "secondary"
    }
  }

  // Função para carregar os dados da ordem
  const loadOrder = async () => {
    if (!orderId) return

    setIsRefreshing(true)
    setError(null)

    try {
      console.log("Carregando ordem:", orderId)
      const { data, error } = await supabase.from("orders").select("*").eq("id", orderId).single()

      if (error) {
        console.error("Erro ao buscar ordem:", error)
        setError(error.message)
        setIsLoading(false)
        setIsRefreshing(false)
        return
      }

      console.log("Ordem carregada:", data)

      if (!data) {
        setError("Ordem não encontrada")
        setIsLoading(false)
        setIsRefreshing(false)
        return
      }

      // Atualizar o timestamp da última atualização
      setLastRefresh(new Date())

      // Verificar se o status mudou
      const statusChanged = order && order.status !== data.status

      setOrder(data)

      // Verificar se a ordem está pendente, verificar o tempo de expiração
      if (data.status === "pending") {
        // Verificar se já existe um tempo de expiração
        if (!data.expiration_time) {
          // Se não existir, definir o tempo de expiração como 10 minutos após a criação
          const expirationTime = new Date(data.created_at)
          expirationTime.setMinutes(expirationTime.getMinutes() + 10)

          // Atualizar o tempo de expiração no banco de dados
          await supabase.from("orders").update({ expiration_time: expirationTime.toISOString() }).eq("id", orderId)

          data.expiration_time = expirationTime.toISOString()
        }

        // Calcular o tempo restante com base no tempo de expiração
        const expirationTime = new Date(data.expiration_time)
        const now = new Date()
        const diffMs = expirationTime.getTime() - now.getTime()
        const diffSeconds = Math.floor(diffMs / 1000)

        // Se já expirou, marcar como expirado
        if (diffSeconds <= 0) {
          setExpired(true)
          // Atualizar o status no banco de dados
          await supabase
            .from("orders")
            .update({
              status: "expired",
              status_text: "Pagamento Expirado",
              updated_at: new Date().toISOString(),
            })
            .eq("id", orderId)
            .eq("status", "pending") // Garantir que só atualize se ainda estiver pendente

          // Atualizar o estado local
          setOrder({
            ...data,
            status: "expired",
            status_text: "Pagamento Expirado",
            updated_at: new Date().toISOString(),
          })
        } else {
          // Caso contrário, iniciar o temporizador
          setTimeLeft(diffSeconds)
          startExpirationTimer(diffSeconds)
        }
      } else {
        // Se não estiver pendente, não precisa de temporizador
        clearInterval(timerRef.current)
        setExpired(data.status === "expired")
      }

      // Se o status mudou e é uma atualização (não o carregamento inicial)
      if (statusChanged && !isLoading) {
        // Aqui você pode adicionar uma notificação ou efeito visual para indicar a mudança de status
        console.log("Status da ordem mudou para:", data.status)
      }
    } catch (err) {
      console.error("Erro ao processar ordem:", err)
      setError(err.message || "Ocorreu um erro ao carregar a ordem")
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Efeito para carregar os dados da ordem
  useEffect(() => {
    loadOrder()

    // Configurar assinatura em tempo real para atualizações da ordem
    let subscription
    if (orderId) {
      subscription = supabase
        .channel(`order-${orderId}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "orders",
            filter: `id=eq.${orderId}`,
          },
          (payload) => {
            console.log("Ordem atualizada:", payload)
            loadOrder()
          },
        )
        .subscribe()
    }

    // Configurar atualização automática a cada 5 segundos
    refreshIntervalRef.current = setInterval(() => {
      console.log("Atualizando dados da ordem a cada 5 segundos")
      loadOrder()
    }, 5000)

    // Verificar periodicamente se a ordem expirou
    const periodicCheck = setInterval(() => {
      if (order?.status === "pending" && order?.expiration_time) {
        const expirationTime = new Date(order.expiration_time)
        const now = new Date()
        if (now >= expirationTime && !expired) {
          setExpired(true)
          updateOrderStatusToExpired()
        }
      }
    }, 10000) // Verificar a cada 10 segundos

    return () => {
      if (subscription) supabase.removeChannel(subscription)
      clearInterval(timerRef.current)
      clearInterval(refreshIntervalRef.current)
      clearInterval(periodicCheck)
    }
  }, [orderId, supabase]) // Removi 'order' das dependências para evitar loops

  if (isLoading) {
    return (
      <div className="container mx-auto py-6 px-4 flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 flex flex-col items-center justify-center py-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
            <p className="text-center">Carregando informações do pedido...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-6 px-4 flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 py-10">
            <div className="text-center">
              <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
              <p className="text-center font-medium">Erro ao carregar ordem</p>
              <p className="text-sm text-muted-foreground mt-1">{error}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="container mx-auto py-6 px-4 flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 py-10">
            <div className="text-center">
              <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
              <p className="text-center font-medium">Ordem não encontrada</p>
              <p className="text-sm text-muted-foreground mt-1">
                O pedido que você está procurando não existe ou foi removido.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 px-4 max-w-md min-h-screen flex items-center justify-center">
      <Card className="shadow-lg border-t-4 border-t-blue-500 w-full">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl">Ordem de Pagamento</CardTitle>
            <Badge variant={getStatusBadgeVariant(order.status)} className="text-xs px-3 py-1">
              {order.status_text || getStatusText(order.status)}
            </Badge>
          </div>
          <div className="mt-1">
            <RefreshIndicator lastRefresh={lastRefresh} isRefreshing={isRefreshing} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status da ordem */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-center">
            <h2 className="font-bold text-lg mb-1">Status da Ordem</h2>
            {order.status === "released" ? (
              <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                <p className="text-green-800 font-medium">Pedido Liberado!</p>
                {order.txid && (
                  <a
                    href={`http://tronscan.org/#/transaction/${order.txid}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-600 hover:underline inline-flex items-center justify-center mt-1"
                  >
                    Ver comprovante da transação
                  </a>
                )}
              </div>
            ) : order.status === "awaiting_release" ? (
              <p className="text-amber-800">Aguardando liberação do pedido</p>
            ) : order.status === "processing" ? (
              <p className="text-blue-800">Processando Pagamento</p>
            ) : order.status === "converting" ? (
              <p className="text-orange-800">Convertendo dinheiro</p>
            ) : order.status === "expired" ? (
              <div className="bg-red-50 p-3 rounded-lg border border-red-100">
                <AlertTriangle className="h-6 w-6 text-red-500 mx-auto mb-2" />
                <p className="text-red-800 font-medium">Pagamento Expirado</p>
                <p className="text-sm text-red-700 mt-1">
                  O tempo para pagamento desta ordem expirou. Por favor, entre em contato com a vendedora para gerar uma
                  nova ordem.
                </p>
              </div>
            ) : (
              <p className="text-amber-800">Aguardando pagamento</p>
            )}
          </div>

          {/* Valor a pagar */}
          <div className="text-center">
            <h3 className="text-sm text-gray-500 mb-1">Valor a pagar</h3>
            <p className="text-2xl font-bold">R$ {Number.parseFloat(order.amount_brl).toFixed(2)}</p>
            <p className="text-xs text-gray-500">${Number.parseFloat(order.amount_usd).toFixed(2)} USD</p>
          </div>

          {/* Instruções de pagamento */}
          {order.status === "pending" && !expired && (
            <div className="space-y-3">
              <h2 className="font-medium text-center">Instruções de Pagamento</h2>

              {/* Temporizador */}
              <div className="text-center mb-2">
                <p className="text-xs text-muted-foreground">Tempo restante para pagamento:</p>
                <p className="text-sm font-medium">{formatTimeLeft()}</p>
              </div>

              <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                <p className="text-sm mb-3">
                  1. Copie o código PIX abaixo
                  <br />
                  2. Abra o aplicativo do seu banco
                  <br />
                  3. Escolha a opção "PIX Copia e Cola"
                  <br />
                  4. Cole o código e confirme o pagamento
                </p>
              </div>

              {/* Código PIX */}
              <div>
                <p className="text-sm font-medium mb-2 text-center">Código PIX Copiar e Colar</p>
                <div className="flex items-center">
                  <div className="bg-white p-3 rounded-md border flex-1 overflow-x-auto font-mono text-sm">
                    {order.payment_code}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    className="ml-2 flex-shrink-0"
                    onClick={copyPaymentCode}
                    title="Copiar código"
                  >
                    {copied ? <Check className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Detalhes da ordem */}
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Cliente</p>
                <p className="font-medium">{order.client_name}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">ID do Cliente</p>
                <p className="font-medium">{order.client_id}</p>
              </div>
            </div>
          </div>
        </CardContent>

        {order.status === "pending" && !expired && (
          <CardFooter className="text-xs text-muted-foreground text-center">
            Esta página expirará em {formatTimeLeft()} se o pagamento não for realizado.
          </CardFooter>
        )}
      </Card>
    </div>
  )
}
