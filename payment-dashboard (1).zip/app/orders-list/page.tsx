"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ExternalLink, ChevronDown, ChevronUp } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { useRouter } from "next/navigation"
import { createClient } from "@/utils/supabase/client"
import RefreshIndicator from "@/components/refresh-indicator"

export default function OrdersList() {
  const [orders, setOrders] = useState([])
  const [groupedOrders, setGroupedOrders] = useState({})
  const [expandedOrders, setExpandedOrders] = useState({})
  const [isLoading, setIsLoading] = useState(true)
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const router = useRouter()
  const supabase = createClient()
  const refreshIntervalRef = useRef(null)

  useEffect(() => {
    // Verificar autenticação
    const checkAuth = async () => {
      const isAuthenticated = localStorage.getItem("authenticated") === "true"
      if (!isAuthenticated) {
        router.push("/login")
        return
      }

      // Carregar ordens
      loadOrders()
    }

    // Carregar ordens do Supabase
    const loadOrders = async () => {
      setIsRefreshing(true)

      try {
        // Carregar todas as ordens
        const { data: ordersData, error: ordersError } = await supabase
          .from("orders")
          .select("*")
          .order("created_at", { ascending: false })

        if (ordersError) throw ordersError
        setOrders(ordersData || [])

        // Atualizar o timestamp da última atualização
        setLastRefresh(new Date())
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar os dados.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
        setIsRefreshing(false)
      }
    }

    // Verificar ordens expiradas
    const checkExpiredOrders = async () => {
      try {
        // Buscar ordens pendentes que já passaram do tempo de expiração
        const now = new Date().toISOString()
        const { data, error } = await supabase
          .from("orders")
          .update({
            status: "expired",
            status_text: "Pagamento Expirado",
            updated_at: now,
          })
          .eq("status", "pending")
          .lt("expiration_time", now)
          .select()

        if (error) throw error

        // Se alguma ordem foi atualizada, recarregar os dados
        if (data && data.length > 0) {
          console.log(`${data.length} ordens foram marcadas como expiradas`)
          loadOrders()
        }
      } catch (error) {
        console.error("Erro ao verificar ordens expiradas:", error)
      }
    }

    checkAuth()
    checkExpiredOrders()

    // Configurar verificação periódica de ordens expiradas
    const expirationInterval = setInterval(checkExpiredOrders, 15000) // Verificar a cada 15 segundos

    // Configurar atualização automática a cada 5 segundos
    refreshIntervalRef.current = setInterval(() => {
      console.log("Atualizando lista de ordens a cada 5 segundos")
      loadOrders()
    }, 5000)

    // Configurar assinatura em tempo real para ordens
    const ordersSubscription = supabase
      .channel("orders-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, loadOrders)
      .subscribe()

    return () => {
      clearInterval(expirationInterval)
      clearInterval(refreshIntervalRef.current)
      supabase.removeChannel(ordersSubscription)
    }
  }, [supabase, router])

  useEffect(() => {
    // Agrupar ordens por data
    const grouped = orders.reduce((acc, order) => {
      const date = new Date(order.created_at).toLocaleDateString("pt-BR")
      if (!acc[date]) {
        acc[date] = []
      }
      acc[date].push(order)
      return acc
    }, {})

    setGroupedOrders(grouped)
  }, [orders])

  const toggleOrderExpand = (orderId) => {
    setExpandedOrders((prev) => ({
      ...prev,
      [orderId]: !prev[orderId],
    }))
  }

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "converting":
        return "warning"
      case "processing":
        return "primary"
      case "awaiting_release":
        return "default"
      case "released":
        return "success"
      case "expired":
        return "destructive"
      default:
        return "secondary"
    }
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  return (
    <div className="container mx-auto py-4 px-4">
      <div className="flex justify-between items-center mb-4">
        <div className="flex flex-col">
          <h1 className="text-2xl font-bold">Ordens Listadas</h1>
          <RefreshIndicator lastRefresh={lastRefresh} isRefreshing={isRefreshing} />
        </div>
      </div>

      {Object.keys(groupedOrders).length === 0 ? (
        <Card>
          <CardContent className="flex items-center justify-center h-40">
            <p className="text-muted-foreground">Nenhuma ordem encontrada.</p>
          </CardContent>
        </Card>
      ) : (
        Object.entries(groupedOrders)
          .sort(([dateA], [dateB]) => {
            const [dayA, monthA, yearA] = dateA.split("/").map(Number)
            const [dayB, monthB, yearB] = dateB.split("/").map(Number)
            return new Date(yearB, monthB - 1, dayB) - new Date(yearA, monthA - 1, dayA)
          })
          .map(([date, dateOrders]) => (
            <div key={date} className="mb-4">
              <h2 className="text-md font-semibold mb-2">{date}</h2>
              <div className="space-y-2">
                {dateOrders.map((order) => (
                  <Card
                    key={order.id}
                    className={`overflow-hidden cursor-pointer transition-all ${
                      order.status === "released"
                        ? "border-green-500 bg-green-50"
                        : order.status === "expired"
                          ? "border-red-500 bg-red-50"
                          : ""
                    }`}
                    onClick={() => toggleOrderExpand(order.id)}
                  >
                    <CardContent className="p-3">
                      {/* Cabeçalho compacto - sempre visível */}
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          {expandedOrders[order.id] ? (
                            <ChevronUp className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          )}
                          <div>
                            <div className="flex items-center gap-1">
                              <span className="font-medium">{order.client_id}</span>
                              <span className="font-medium">-</span>
                              <span className="font-medium">{order.client_name}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {order.seller_name} / {order.store}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">${Number.parseFloat(order.amount_usd).toFixed(2)}</p>
                          <p className="text-xs">R$ {Number.parseFloat(order.amount_brl).toFixed(2)}</p>
                        </div>
                      </div>

                      {/* Conteúdo expandido - visível apenas quando expandido */}
                      {expandedOrders[order.id] && (
                        <div className="mt-3 pt-3 border-t">
                          <div className="text-sm mb-2">
                            {order.wallet && <p className="truncate">Carteira: {order.wallet}</p>}
                            <div className="flex items-center mt-1">
                              <Badge variant={getStatusBadgeVariant(order.status)} className="mr-2">
                                {order.status_text || "Aguardando Pagamento"}
                              </Badge>
                              {order.txid && (
                                <a
                                  href={`http://tronscan.org/#/transaction/${order.txid}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-blue-600 hover:underline inline-flex items-center"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  Ver transação <ExternalLink className="h-3 w-3 ml-1" />
                                </a>
                              )}
                            </div>
                          </div>

                          {order.notes && (
                            <div className="bg-gray-50 p-2 rounded-md mb-3 text-sm">
                              <p className="font-medium text-xs mb-1">Notas:</p>
                              {order.notes.split("\n").map((note, i) => (
                                <p key={i} className="text-sm">
                                  {note}
                                </p>
                              ))}
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2 mt-3">
                            <Link href={`/order/${order.id}`} className="flex-1" onClick={(e) => e.stopPropagation()}>
                              <Button variant="outline" size="sm" className="w-full">
                                <ExternalLink className="h-4 w-4 mr-1" /> Ver Detalhes
                              </Button>
                            </Link>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))
      )}

      <Toaster />
    </div>
  )
}
