"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Share2, ExternalLink, RefreshCw, CheckCircle } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { createClient } from "@/utils/supabase/client"
import RefreshIndicator from "@/components/refresh-indicator"

export default function SellerPanel() {
  const params = useParams()
  const router = useRouter()
  const sellerId = params.id
  const [seller, setSeller] = useState(null)
  const [orders, setOrders] = useState([])
  const [usdtRate, setUsdtRate] = useState(0)
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [lastDataUpdate, setLastDataUpdate] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("quote")
  const [expandedOrderId, setExpandedOrderId] = useState(null)
  const supabase = createClient()
  const intervalRef = useRef(null)

  const loadData = async () => {
    try {
      setIsRefreshing(true)
      // Carregar dados da vendedora
      const { data: sellerData, error: sellerError } = await supabase
        .from("sellers")
        .select("*")
        .eq("id", sellerId)
        .single()

      if (sellerError) {
        if (sellerError.code === "PGRST116") {
          // Vendedora não encontrada
          router.push("/")
          return
        }
        throw sellerError
      }

      setSeller(sellerData)

      // Carregar ordens desta vendedora
      const { data: ordersData, error: ordersError } = await supabase
        .from("orders")
        .select("*")
        .eq("seller_id", sellerId)
        .order("created_at", { ascending: false })

      if (ordersError) throw ordersError

      setOrders(ordersData || [])
      setIsLoading(false)
      setLastDataUpdate(new Date())
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao carregar os dados.",
        variant: "destructive",
      })
    } finally {
      setIsRefreshing(false)
    }
  }

  useEffect(() => {
    // Carregar dados da vendedora e ordens
    loadData()

    // Carregar cotação
    const fetchRate = async () => {
      try {
        const response = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=USDTBRL")
        const data = await response.json()
        // Aplicar a margem de 0.7%
        const rateWithMargin = Number.parseFloat(data.price) * 1.007
        setUsdtRate(rateWithMargin)
        setLastUpdate(new Date())
      } catch (error) {
        console.error("Erro ao buscar cotação:", error)
      }
    }

    fetchRate()

    // Configurar assinaturas em tempo real
    const ordersSubscription = supabase
      .channel(`seller-orders-${sellerId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "orders",
          filter: `seller_id=eq.${sellerId}`,
        },
        loadData,
      )
      .subscribe()

    // Atualizar a cada 5 segundos
    const rateInterval = setInterval(() => {
      fetchRate()
    }, 5000)

    // Atualizar dados a cada 5 segundos quando estiver na aba de ordens
    const dataRefreshInterval = setInterval(() => {
      if (activeTab === "orders") {
        console.log("Atualizando dados da vendedora a cada 5 segundos")
        loadData()
      }
    }, 5000)

    // Verificar ordens expiradas periodicamente
    const checkExpiredOrders = async () => {
      const now = new Date().toISOString()

      // Verificar se há ordens pendentes que já expiraram
      const { data: expiredOrders } = await supabase
        .from("orders")
        .select("id")
        .eq("status", "pending")
        .eq("seller_id", sellerId)
        .lt("expiration_time", now)

      // Se houver ordens expiradas, recarregar os dados
      if (expiredOrders && expiredOrders.length > 0) {
        loadData()
      }
    }

    // Configurar intervalo para verificar ordens expiradas
    const expirationInterval = setInterval(checkExpiredOrders, 20000) // A cada 20 segundos

    return () => {
      clearInterval(rateInterval)
      clearInterval(dataRefreshInterval)
      clearInterval(expirationInterval)
      supabase.removeChannel(ordersSubscription)
    }
  }, [sellerId, router, supabase, activeTab])

  const copyShareLink = (orderId, e) => {
    if (e) e.stopPropagation()
    const shareUrl = `${window.location.origin}/order/${orderId}`
    navigator.clipboard.writeText(shareUrl)
    toast({
      title: "Link copiado",
      description: "O link para compartilhar foi copiado para a área de transferência.",
    })
  }

  const handleReleaseOrder = async (orderId, e) => {
    if (e) e.stopPropagation()
    try {
      // Atualizar o status da ordem para "released"
      const { error } = await supabase
        .from("orders")
        .update({
          status: "released",
          status_text: "Pedido Liberado",
          updated_at: new Date().toISOString(),
        })
        .eq("id", orderId)

      if (error) throw error

      // Atualizar ordens locais
      setOrders(
        orders.map((order) => {
          if (order.id === orderId) {
            return {
              ...order,
              status: "released",
              status_text: "Pedido Liberado",
              updated_at: new Date().toISOString(),
            }
          }
          return order
        }),
      )

      toast({
        title: "Pedido liberado",
        description: "O pedido foi marcado como liberado com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao liberar pedido:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao liberar o pedido.",
        variant: "destructive",
      })
    }
  }

  const toggleOrderExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId)
  }

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "converting":
        return "warning"
      case "processing":
        return "primary"
      case "awaiting_release":
        return "default"
      case "released":
        return "success"
      case "expired":
        return "destructive"
      default:
        return "secondary"
    }
  }

  const handleTabChange = (value) => {
    setActiveTab(value)
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  if (!seller) {
    return <div className="flex items-center justify-center min-h-screen">Vendedora não encontrada</div>
  }

  return (
    <div className="container mx-auto py-4 px-4">
      <div className="flex justify-between items-center mb-4">
        <div className="flex flex-col">
          <h1 className="text-xl font-bold">Painel de Ordens</h1>
          <RefreshIndicator lastRefresh={lastDataUpdate} isRefreshing={isRefreshing} />
        </div>
        <p className="text-sm text-muted-foreground">
          {seller.name} / {seller.store}
        </p>
      </div>

      <Tabs defaultValue="quote" onValueChange={handleTabChange}>
        <TabsList className="mb-4 w-full">
          <TabsTrigger value="quote" className="flex-1">
            Cotação e Pedido
          </TabsTrigger>
          <TabsTrigger value="orders" className="flex-1">
            Minhas Ordens
          </TabsTrigger>
        </TabsList>

        <TabsContent value="quote">
          <Card className="mb-4">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Cotação USD/BRL</CardTitle>
                <div className="flex items-center text-xs text-muted-foreground">
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Atualizado: {lastUpdate.toLocaleTimeString()}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-6">
                <p className="text-3xl font-bold mb-2">R$ {usdtRate.toFixed(3)}</p>
                <p className="text-sm text-muted-foreground">1USD = {usdtRate.toFixed(3)}BRL</p>
              </div>

              <div className="flex justify-center mt-4">
                <Link href={`/seller/${sellerId}/request`}>
                  <Button size="lg">Pedir Nova Ordem</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          {orders.length === 0 ? (
            <Card>
              <CardContent className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Nenhuma ordem encontrada para esta vendedora.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {orders.map((order) => (
                <Card
                  key={order.id}
                  className={`overflow-hidden cursor-pointer ${
                    order.status === "released"
                      ? "border-green-500"
                      : order.status === "expired"
                        ? "border-red-500"
                        : ""
                  }`}
                  onClick={() => toggleOrderExpand(order.id)}
                >
                  <CardContent className="p-3">
                    {/* Cabeçalho compacto - sempre visível */}
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="flex items-center gap-1">
                          <span className="font-medium text-sm">{order.client_id}</span>
                          <span className="font-medium text-sm">-</span>
                          <span className="font-medium text-sm">{order.client_name}</span>
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <Badge variant={getStatusBadgeVariant(order.status)} className="text-xs">
                            {order.status_text || "Aguardando Pagamento"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(order.created_at).toLocaleDateString("pt-BR")}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${Number.parseFloat(order.amount_usd).toFixed(2)}</p>
                        <p className="text-xs">R$ {Number.parseFloat(order.amount_brl).toFixed(2)}</p>
                      </div>
                    </div>

                    {/* Conteúdo expandido - visível apenas quando expandido */}
                    {expandedOrderId === order.id && (
                      <div className="mt-3 pt-3 border-t">
                        {order.notes && (
                          <div className="bg-gray-50 p-2 rounded-md mb-3 text-sm">
                            <p className="font-medium text-xs mb-1">Notas:</p>
                            {order.notes.split("\n").map((note, i) => (
                              <p key={i} className="text-sm">
                                {note}
                              </p>
                            ))}
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2 mt-3">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 text-xs h-8"
                            onClick={(e) => copyShareLink(order.id, e)}
                          >
                            <Share2 className="h-3 w-3 mr-1" /> Compartilhar
                          </Button>

                          <Link href={`/order/${order.id}`} className="flex-1" onClick={(e) => e.stopPropagation()}>
                            <Button variant="outline" size="sm" className="w-full text-xs h-8">
                              <ExternalLink className="h-3 w-3 mr-1" /> Ver
                            </Button>
                          </Link>

                          {order.status === "awaiting_release" && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1 text-xs h-8"
                              onClick={(e) => handleReleaseOrder(order.id, e)}
                            >
                              <CheckCircle className="h-3 w-3 mr-1" /> Liberar Pedido
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Toaster />
    </div>
  )
}
