"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { createClient } from "@/utils/supabase/client"

export default function RequestOrder() {
  const params = useParams()
  const router = useRouter()
  const sellerId = params.id
  const [seller, setSeller] = useState(null)
  const [usdtRate, setUsdtRate] = useState(0)
  const [formData, setFormData] = useState({
    client_id: "",
    client_name: "",
    amount_usd: "",
    notes: "",
    wallet: "",
  })
  const [amountBRL, setAmountBRL] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    // Carregar dados da vendedora
    const loadSeller = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase.from("sellers").select("*").eq("id", sellerId).single()

        if (error) {
          if (error.code === "PGRST116") {
            // Vendedora não encontrada
            router.push("/")
            return
          }
          throw error
        }

        setSeller(data)
      } catch (error) {
        console.error("Erro ao carregar vendedora:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar os dados da vendedora.",
          variant: "destructive",
        })
        router.push("/")
      } finally {
        setIsLoading(false)
      }
    }

    loadSeller()

    // Carregar cotação
    const fetchRate = async () => {
      try {
        const response = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=USDTBRL")
        const data = await response.json()
        // Aplicar a margem de 0.7%
        const rateWithMargin = Number.parseFloat(data.price) * 1.007
        setUsdtRate(rateWithMargin)
      } catch (error) {
        console.error("Erro ao buscar cotação:", error)
      }
    }

    fetchRate()

    // Atualizar a cada 3 segundos
    const interval = setInterval(fetchRate, 3000)

    return () => clearInterval(interval)
  }, [sellerId, router, supabase])

  useEffect(() => {
    if (formData.amount_usd && usdtRate) {
      const usdValue = Number.parseFloat(formData.amount_usd)
      if (!isNaN(usdValue)) {
        const brlValue = usdValue * usdtRate
        setAmountBRL(brlValue.toFixed(2))
      }
    } else {
      setAmountBRL("")
    }
  }, [formData.amount_usd, usdtRate])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!seller || isSubmitting) return

    setIsSubmitting(true)

    try {
      // Criar objeto de pedido de ordem
      const orderRequest = {
        seller_id: sellerId,
        seller_name: seller.name,
        store: seller.store,
        client_id: formData.client_id,
        client_name: formData.client_name,
        amount_usd: formData.amount_usd,
        amount_brl: amountBRL,
        wallet: formData.wallet,
        notes: formData.notes,
        seen: false,
      }

      // Inserir pedido no Supabase
      const { error } = await supabase.from("order_requests").insert(orderRequest)

      if (error) throw error

      // Mostrar mensagem de sucesso
      toast({
        title: "Pedido enviado",
        description: "Seu pedido de ordem foi enviado com sucesso.",
      })

      // Redirecionar para o painel da vendedora
      setTimeout(() => {
        router.push(`/seller/${sellerId}`)
      }, 1500)
    } catch (error) {
      console.error("Erro ao enviar pedido:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao enviar o pedido.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  if (!seller) {
    return <div className="flex items-center justify-center min-h-screen">Vendedora não encontrada</div>
  }

  return (
    <div className="container mx-auto py-4 px-4 max-w-3xl">
      <div className="flex items-center mb-4">
        <Link href={`/seller/${sellerId}`} className="mr-4">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-xl font-bold">Pedir Nova Ordem</h1>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Detalhes do Pedido</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="client_id" className="text-xs">
                  ID do Cliente
                </Label>
                <Input
                  id="client_id"
                  name="client_id"
                  value={formData.client_id}
                  onChange={handleChange}
                  required
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="client_name" className="text-xs">
                  Nome do Cliente
                </Label>
                <Input
                  id="client_name"
                  name="client_name"
                  value={formData.client_name}
                  onChange={handleChange}
                  required
                  className="h-9"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="amount_usd" className="text-xs">
                  Valor Total do Pedido (USD)
                </Label>
                <Input
                  id="amount_usd"
                  name="amount_usd"
                  type="number"
                  step="0.01"
                  value={formData.amount_usd}
                  onChange={handleChange}
                  required
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="amountBRL" className="text-xs">
                  Valor em BRL (Cotação: {usdtRate.toFixed(3)})
                </Label>
                <Input id="amountBRL" value={amountBRL} readOnly className="bg-gray-50 h-9" />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="notes" className="text-xs">
                Notas (uma por linha)
              </Label>
              <Textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                className="resize-none"
              />
            </div>

            <div className="space-y-1">
              <Label htmlFor="wallet" className="text-xs">
                Carteira para Pagamento (opcional)
              </Label>
              <Input id="wallet" name="wallet" value={formData.wallet} onChange={handleChange} className="h-9" />
            </div>

            <CardFooter className="px-0 pt-2 pb-0">
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Enviando..." : "Enviar Pedido"}
              </Button>
            </CardFooter>
          </form>
        </CardContent>
      </Card>

      <Toaster />
    </div>
  )
}
