"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, ExternalLink, Copy, Check, UserPlus, Trash2 } from "lucide-react"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import AddSellerModal from "@/components/add-seller-modal"
import PinModal from "@/components/pin-modal"
import { createClient } from "@/utils/supabase/client"

export default function SellersList() {
  const [sellers, setSellers] = useState([])
  const [copiedId, setCopiedId] = useState(null)
  const [showAddSellerModal, setShowAddSellerModal] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [showPinModal, setShowPinModal] = useState(false)
  const [selectedSellerId, setSelectedSellerId] = useState(null)
  const [selectedSellerName, setSelectedSellerName] = useState("")
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    // Verificar autenticação
    const checkAuth = async () => {
      const isAuthenticated = localStorage.getItem("authenticated") === "true"
      if (!isAuthenticated) {
        router.push("/login")
        return
      }

      // Carregar vendedoras
      loadSellers()
    }

    const loadSellers = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase.from("sellers").select("*").order("name")

        if (error) throw error

        setSellers(data || [])
      } catch (error) {
        console.error("Erro ao carregar vendedoras:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar as vendedoras.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()

    // Configurar assinatura em tempo real para vendedoras
    const subscription = supabase
      .channel("sellers-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "sellers" }, loadSellers)
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [router, supabase])

  const copySellerLink = (sellerId) => {
    const sellerUrl = `${window.location.origin}/seller/${sellerId}`
    navigator.clipboard.writeText(sellerUrl)
    setCopiedId(sellerId)
    toast({
      title: "Link copiado",
      description: "O link do painel da vendedora foi copiado para a área de transferência.",
    })
    setTimeout(() => setCopiedId(null), 2000)
  }

  const handleAddSeller = async (seller) => {
    try {
      // Adicionar vendedora
      const { data: sellerData, error: sellerError } = await supabase
        .from("sellers")
        .insert({
          name: seller.name,
          store: seller.store,
        })
        .select()
        .single()

      if (sellerError) throw sellerError

      // Verificar se a loja já existe no financeiro
      const { data: financeData, error: financeCheckError } = await supabase
        .from("finances")
        .select("id")
        .eq("store", seller.store)
        .maybeSingle()

      if (financeCheckError) throw financeCheckError

      // Se a loja não existir, criar um novo painel financeiro
      if (!financeData) {
        const { error: financeError } = await supabase.from("finances").insert({
          store: seller.store,
        })

        if (financeError) throw financeError
      }

      setSellers([...sellers, sellerData])

      toast({
        title: "Vendedora adicionada",
        description: `${seller.name} foi adicionada com sucesso.`,
      })

      setShowAddSellerModal(false)
    } catch (error) {
      console.error("Erro ao adicionar vendedora:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao adicionar a vendedora.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteClick = (sellerId, sellerName) => {
    setSelectedSellerId(sellerId)
    setSelectedSellerName(sellerName)
    setShowPinModal(true)
  }

  const handlePinVerified = async () => {
    setShowPinModal(false)

    if (!selectedSellerId) return

    try {
      setIsLoading(true)

      // Verificar se existem ordens associadas a esta vendedora
      const { data: ordersData, error: ordersError } = await supabase
        .from("orders")
        .select("id")
        .eq("seller_id", selectedSellerId)
        .limit(1)

      if (ordersError) throw ordersError

      if (ordersData && ordersData.length > 0) {
        toast({
          title: "Não é possível excluir",
          description: "Esta vendedora possui ordens associadas e não pode ser excluída.",
          variant: "destructive",
        })
        return
      }

      // Excluir a vendedora
      const { error: deleteError } = await supabase.from("sellers").delete().eq("id", selectedSellerId)

      if (deleteError) throw deleteError

      // Atualizar a lista de vendedoras
      setSellers(sellers.filter((seller) => seller.id !== selectedSellerId))

      toast({
        title: "Vendedora excluída",
        description: `${selectedSellerName} foi excluída com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao excluir vendedora:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao excluir a vendedora.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
      setSelectedSellerId(null)
      setSelectedSellerName("")
    }
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  return (
    <div className="container mx-auto py-4 px-4 max-w-3xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Link href="/" className="mr-4">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Vendedoras Cadastradas</h1>
        </div>
        <Button onClick={() => setShowAddSellerModal(true)}>
          <UserPlus className="h-4 w-4 mr-2" /> Nova Vendedora
        </Button>
      </div>

      {sellers.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-40">
            <p className="text-muted-foreground mb-4">Nenhuma vendedora cadastrada.</p>
            <Button onClick={() => setShowAddSellerModal(true)}>
              <UserPlus className="h-4 w-4 mr-2" /> Adicionar Vendedora
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sellers.map((seller) => (
            <Card key={seller.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="font-medium text-lg">{seller.name}</h2>
                    <p className="text-sm text-muted-foreground">Loja: {seller.store}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copySellerLink(seller.id)}
                      className="flex items-center"
                    >
                      {copiedId === seller.id ? (
                        <>
                          <Check className="h-4 w-4 mr-1" /> Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4 mr-1" /> Copiar Link
                        </>
                      )}
                    </Button>
                    <Link href={`/seller/${seller.id}`}>
                      <Button size="sm" className="flex items-center">
                        <ExternalLink className="h-4 w-4 mr-1" /> Acessar Painel
                      </Button>
                    </Link>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="flex items-center"
                      onClick={() => handleDeleteClick(seller.id, seller.name)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" /> Excluir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showAddSellerModal && (
        <AddSellerModal onClose={() => setShowAddSellerModal(false)} onAddSeller={handleAddSeller} />
      )}

      {showPinModal && (
        <PinModal
          onClose={() => setShowPinModal(false)}
          onPinVerified={handlePinVerified}
          action={`excluir a vendedora ${selectedSellerName}`}
        />
      )}

      <Toaster />
    </div>
  )
}
