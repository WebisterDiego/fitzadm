"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"

interface CreateOrderFromRequestModalProps {
  request: any
  onClose: () => void
  onOrderCreated: (order: any) => void
}

export default function CreateOrderFromRequestModal({
  request,
  onClose,
  onOrderCreated,
}: CreateOrderFromRequestModalProps) {
  const [paymentCode, setPaymentCode] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = () => {
    if (!paymentCode.trim()) {
      setError("Por favor, insira o código de pagamento.")
      return
    }

    setIsLoading(true)

    // Calcular o tempo de expiração (10 minutos a partir de agora)
    const expirationTime = new Date()
    expirationTime.setMinutes(expirationTime.getMinutes() + 10) // Alterado para 10 minutos

    // Criar nova ordem baseada no pedido
    const newOrder = {
      seller_id: request.seller_id,
      seller_name: request.seller_name,
      store: request.store,
      client_id: request.client_id,
      client_name: request.client_name,
      amount_usd: request.amount_usd,
      amount_brl: request.amount_brl,
      payment_code: paymentCode,
      wallet: request.wallet,
      notes: request.notes,
      status: "pending",
      status_text: "Aguardando Pagamento",
      expiration_time: expirationTime.toISOString(),
    }

    onOrderCreated(newOrder)
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Criar Ordem a partir do Pedido</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-1">
            <p className="text-sm font-medium">Cliente: {request.client_name}</p>
            <p className="text-sm">ID: {request.client_id}</p>
            <p className="text-sm">
              Vendedora: {request.seller_name} / {request.store}
            </p>
            <p className="text-sm">
              Valor: ${request.amount_usd} (R$ {request.amount_brl})
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="paymentCode">Código de Pagamento</Label>
            <Input
              id="paymentCode"
              value={paymentCode}
              onChange={(e) => setPaymentCode(e.target.value)}
              placeholder="Digite o código de pagamento"
            />
            {error && <p className="text-sm text-red-500">{error}</p>}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? "Criando..." : "Criar Ordem"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
