"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertTriangle, Info } from "lucide-react"
import { createClient } from "@/utils/supabase/client"

export default function DashboardReview() {
  const [isLoading, setIsLoading] = useState(true)
  const [dbStatus, setDbStatus] = useState<"success" | "warning" | "error">("warning")
  const [dbMessage, setDbMessage] = useState("Verificando conexão com o banco de dados...")
  const [ordersStatus, setOrdersStatus] = useState<"success" | "warning" | "error">("warning")
  const [ordersMessage, setOrdersMessage] = useState("Verificando integridade das ordens...")
  const [sellersStatus, setSellersStatus] = useState<"success" | "warning" | "error">("warning")
  const [sellersMessage, setSellersMessage] = useState("Verificando vendedores...")
  const [expiredOrdersCount, setExpiredOrdersCount] = useState(0)
  const [pendingOrdersCount, setPendingOrdersCount] = useState(0)
  const [totalOrdersCount, setTotalOrdersCount] = useState(0)
  const [unseenRequestsCount, setUnseenRequestsCount] = useState(0)
  const supabase = createClient()

  useEffect(() => {
    const checkSystem = async () => {
      setIsLoading(true)

      try {
        // Verificar conexão com o banco de dados
        const { data: healthCheck, error: healthError } = await supabase
          .from("orders")
          .select("count()", { count: "exact" })
          .limit(1)

        if (healthError) {
          setDbStatus("error")
          setDbMessage("Erro na conexão com o banco de dados: " + healthError.message)
        } else {
          setDbStatus("success")
          setDbMessage("Conexão com o banco de dados estabelecida com sucesso")
        }

        // Verificar ordens
        const { data: ordersData, error: ordersError } = await supabase
          .from("orders")
          .select("id, status, expiration_time, created_at", { count: "exact" })

        if (ordersError) {
          setOrdersStatus("error")
          setOrdersMessage("Erro ao verificar ordens: " + ordersError.message)
        } else {
          setTotalOrdersCount(ordersData.length)

          // Verificar ordens expiradas
          const now = new Date()
          const expiredOrders = ordersData.filter(
            (order) => order.status === "pending" && order.expiration_time && new Date(order.expiration_time) < now,
          )
          setExpiredOrdersCount(expiredOrders.length)

          // Verificar ordens pendentes
          const pendingOrders = ordersData.filter((order) => order.status === "pending")
          setPendingOrdersCount(pendingOrders.length)

          if (expiredOrders.length > 0) {
            setOrdersStatus("warning")
            setOrdersMessage(`Encontradas ${expiredOrders.length} ordens que deveriam estar expiradas`)
          } else {
            setOrdersStatus("success")
            setOrdersMessage(`Sistema de ordens funcionando corretamente (${ordersData.length} ordens no total)`)
          }
        }

        // Verificar vendedores
        const { data: sellersData, error: sellersError } = await supabase
          .from("sellers")
          .select("id, name, store", { count: "exact" })

        if (sellersError) {
          setSellersStatus("error")
          setSellersMessage("Erro ao verificar vendedores: " + sellersError.message)
        } else {
          setSellersStatus("success")
          setSellersMessage(`${sellersData.length} vendedores encontrados no sistema`)
        }

        // Verificar pedidos não vistos
        const { data: requestsData, error: requestsError } = await supabase
          .from("order_requests")
          .select("id")
          .eq("seen", false)

        if (!requestsError && requestsData) {
          setUnseenRequestsCount(requestsData.length)
        }
      } catch (error) {
        console.error("Erro ao verificar sistema:", error)
        setDbStatus("error")
        setDbMessage("Erro ao verificar sistema: " + (error as Error).message)
      } finally {
        setIsLoading(false)
      }
    }

    checkSystem()
  }, [supabase])

  const fixExpiredOrders = async () => {
    try {
      setIsLoading(true)

      // Atualizar ordens expiradas
      const now = new Date().toISOString()
      const { data, error } = await supabase
        .from("orders")
        .update({
          status: "expired",
          status_text: "Pagamento Expirado",
          updated_at: now,
        })
        .eq("status", "pending")
        .lt("expiration_time", now)
        .select()

      if (error) throw error

      setExpiredOrdersCount(0)
      setOrdersStatus("success")
      setOrdersMessage(`Sistema corrigido. ${data.length} ordens atualizadas para expiradas.`)
    } catch (error) {
      console.error("Erro ao corrigir ordens:", error)
      setOrdersStatus("error")
      setOrdersMessage("Erro ao corrigir ordens expiradas: " + (error as Error).message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-6 px-4 max-w-4xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl">Diagnóstico do Sistema</CardTitle>
      </CardHeader>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              {dbStatus === "success" ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : dbStatus === "warning" ? (
                <Info className="h-5 w-5 text-amber-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-500" />
              )}
              Conexão com Banco de Dados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p
              className={`text-sm ${
                dbStatus === "success" ? "text-green-600" : dbStatus === "warning" ? "text-amber-600" : "text-red-600"
              }`}
            >
              {dbMessage}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              {ordersStatus === "success" ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : ordersStatus === "warning" ? (
                <Info className="h-5 w-5 text-amber-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-500" />
              )}
              Sistema de Ordens
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p
              className={`text-sm ${
                ordersStatus === "success"
                  ? "text-green-600"
                  : ordersStatus === "warning"
                    ? "text-amber-600"
                    : "text-red-600"
              }`}
            >
              {ordersMessage}
            </p>

            {expiredOrdersCount > 0 && (
              <div className="mt-4">
                <Button onClick={fixExpiredOrders} disabled={isLoading}>
                  Corrigir {expiredOrdersCount} Ordens Expiradas
                </Button>
              </div>
            )}

            <div className="mt-4 grid grid-cols-3 gap-2">
              <div className="bg-gray-50 p-2 rounded-md text-center">
                <p className="text-xs text-gray-500">Total</p>
                <p className="text-lg font-bold">{totalOrdersCount}</p>
              </div>
              <div className="bg-amber-50 p-2 rounded-md text-center">
                <p className="text-xs text-amber-500">Pendentes</p>
                <p className="text-lg font-bold">{pendingOrdersCount}</p>
              </div>
              <div className="bg-red-50 p-2 rounded-md text-center">
                <p className="text-xs text-red-500">Expiradas</p>
                <p className="text-lg font-bold">{expiredOrdersCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              {sellersStatus === "success" ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : sellersStatus === "warning" ? (
                <Info className="h-5 w-5 text-amber-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-500" />
              )}
              Vendedores e Lojas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p
              className={`text-sm ${
                sellersStatus === "success"
                  ? "text-green-600"
                  : sellersStatus === "warning"
                    ? "text-amber-600"
                    : "text-red-600"
              }`}
            >
              {sellersMessage}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Info className="h-5 w-5 text-blue-500" />
              Notificações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {unseenRequestsCount > 0 ? (
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{unseenRequestsCount}</Badge>
                  <p className="text-sm">Pedidos de ordem não visualizados</p>
                </div>
              ) : (
                <p className="text-sm text-green-600">Não há pedidos pendentes de visualização</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Recomendações de Melhoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                <span>Verificação periódica de ordens expiradas está funcionando corretamente</span>
              </li>
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-amber-500 mt-0.5" />
                <span>
                  Considere adicionar índices para campos frequentemente consultados como <code>status</code> e{" "}
                  <code>seller_id</code>
                </span>
              </li>
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-amber-500 mt-0.5" />
                <span>Implemente um sistema de backup automático para os dados críticos</span>
              </li>
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-amber-500 mt-0.5" />
                <span>Adicione validações adicionais nos formulários para garantir a integridade dos dados</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
