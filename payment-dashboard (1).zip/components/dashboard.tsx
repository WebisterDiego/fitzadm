"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Plus,
  Trash2,
  CheckCircle,
  Share2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  LogOut,
  Bell,
  Users,
  DollarSign,
  Building,
  Activity,
} from "lucide-react"
import Link from "next/link"
import PinModal from "@/components/pin-modal"
import TxidModal from "@/components/txid-modal"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import CreateOrderFromRequestModal from "@/components/create-order-from-request-modal"
import AddSellerModal from "@/components/add-seller-modal"
import { createClient } from "@/utils/supabase/client"
import NotificationAlert from "@/components/notification-alert"
import RefreshIndicator from "@/components/refresh-indicator"

export default function Dashboard() {
  const [orders, setOrders] = useState([])
  const [orderRequests, setOrderRequests] = useState([])
  const [previousRequestCount, setPreviousRequestCount] = useState(0)
  const [groupedOrders, setGroupedOrders] = useState({})
  const [showPinModal, setShowPinModal] = useState(false)
  const [showTxidModal, setShowTxidModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [actionType, setActionType] = useState(null)
  const [expandedOrders, setExpandedOrders] = useState({})
  const [hasNewRequests, setHasNewRequests] = useState(false)
  const [showCreateFromRequestModal, setShowCreateFromRequestModal] = useState(false)
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [showAddSellerModal, setShowAddSellerModal] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("orders")
  const [showNotification, setShowNotification] = useState(false)
  const [newRequestsCount, setNewRequestsCount] = useState(0)
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const router = useRouter()
  const supabase = createClient()
  const initialLoadRef = useRef(true)

  useEffect(() => {
    // Verificar ordens expiradas
    const checkExpiredOrders = async () => {
      try {
        // Buscar ordens pendentes que já passaram do tempo de expiração
        const now = new Date().toISOString()
        const { data, error } = await supabase
          .from("orders")
          .update({
            status: "expired",
            status_text: "Pagamento Expirado",
            updated_at: now,
          })
          .eq("status", "pending")
          .lt("expiration_time", now)
          .select()

        if (error) throw error

        // Se alguma ordem foi atualizada, recarregar os dados
        if (data && data.length > 0) {
          console.log(`${data.length} ordens foram marcadas como expiradas`)
          loadData()
        }
      } catch (error) {
        console.error("Erro ao verificar ordens expiradas:", error)
      }
    }

    // Carregar ordens e pedidos do Supabase
    const loadData = async () => {
      setIsRefreshing(true)

      try {
        // Carregar ordens
        const { data: ordersData, error: ordersError } = await supabase
          .from("orders")
          .select("*")
          .order("created_at", { ascending: false })

        if (ordersError) throw ordersError
        setOrders(ordersData || [])

        // Carregar pedidos de ordem
        const { data: requestsData, error: requestsError } = await supabase
          .from("order_requests")
          .select("*")
          .order("created_at", { ascending: false })

        if (requestsError) throw requestsError

        // Verificar se há novos pedidos
        const currentRequestCount = requestsData?.length || 0

        if (!initialLoadRef.current && currentRequestCount > previousRequestCount) {
          // Calcular quantos novos pedidos chegaram
          const newCount = currentRequestCount - previousRequestCount
          setNewRequestsCount(newCount)
          setShowNotification(true)
        }

        setPreviousRequestCount(currentRequestCount)
        setOrderRequests(requestsData || [])

        // Verificar se há novos pedidos não vistos
        const hasUnseen = (requestsData || []).some((req) => !req.seen)
        setHasNewRequests(hasUnseen)

        // Atualizar o timestamp da última atualização
        setLastRefresh(new Date())
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao carregar os dados.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
        setIsRefreshing(false)
        // Marcar que o carregamento inicial foi concluído
        initialLoadRef.current = false
      }
    }

    // Verificar ordens expiradas e carregar dados
    checkExpiredOrders()
    loadData()

    // Configurar verificação periódica de ordens expiradas
    const expirationInterval = setInterval(checkExpiredOrders, 15000) // Verificar a cada 15 segundos

    // Atualizar dados a cada 5 segundos
    const refreshInterval = setInterval(() => {
      if (activeTab === "orders") {
        console.log("Atualizando dados do dashboard a cada 5 segundos")
        loadData()
      }
    }, 5000)

    // Configurar assinatura em tempo real para ordens e pedidos
    const ordersSubscription = supabase
      .channel("orders-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, loadData)
      .subscribe()

    const requestsSubscription = supabase
      .channel("requests-changes")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "order_requests" }, (payload) => {
        // Quando um novo pedido for inserido, recarregar os dados
        loadData()
      })
      .subscribe()

    return () => {
      clearInterval(expirationInterval)
      clearInterval(refreshInterval)
      supabase.removeChannel(ordersSubscription)
      supabase.removeChannel(requestsSubscription)
    }
  }, [supabase, previousRequestCount, activeTab])

  useEffect(() => {
    // Agrupar ordens por data
    const grouped = orders.reduce((acc, order) => {
      const date = new Date(order.created_at).toLocaleDateString("pt-BR")
      if (!acc[date]) {
        acc[date] = []
      }
      acc[date].push(order)
      return acc
    }, {})

    setGroupedOrders(grouped)
  }, [orders])

  const handleDeleteClick = (e, orderId) => {
    e.stopPropagation()
    setSelectedOrderId(orderId)
    setActionType("delete")
    setShowPinModal(true)
  }

  const handleMarkAsPaidClick = (e, orderId) => {
    e.stopPropagation()
    setSelectedOrderId(orderId)
    setActionType("markAsPaid")
    setShowPinModal(true)
  }

  const handleConvertingClick = (e, orderId) => {
    e.stopPropagation()
    setSelectedOrderId(orderId)
    setActionType("converting")
    setShowPinModal(true)
  }

  const handlePinVerified = async () => {
    setShowPinModal(false)

    if (actionType === "delete") {
      try {
        const { error } = await supabase.from("orders").delete().eq("id", selectedOrderId)

        if (error) throw error

        setOrders(orders.filter((order) => order.id !== selectedOrderId))

        toast({
          title: "Ordem excluída",
          description: "A ordem foi excluída com sucesso.",
        })
      } catch (error) {
        console.error("Erro ao excluir ordem:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao excluir a ordem.",
          variant: "destructive",
        })
      }
    } else if (actionType === "markAsPaid") {
      setShowTxidModal(true)
    } else if (actionType === "converting") {
      try {
        const { error } = await supabase
          .from("orders")
          .update({
            status: "converting",
            status_text: "Convertendo Dinheiro",
            updated_at: new Date().toISOString(),
          })
          .eq("id", selectedOrderId)

        if (error) throw error

        setOrders(
          orders.map((order) => {
            if (order.id === selectedOrderId) {
              return {
                ...order,
                status: "converting",
                status_text: "Convertendo Dinheiro",
                updated_at: new Date().toISOString(),
              }
            }
            return order
          }),
        )

        toast({
          title: "Status atualizado",
          description: "A ordem foi marcada como 'Convertendo Dinheiro'.",
        })
      } catch (error) {
        console.error("Erro ao atualizar status:", error)
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao atualizar o status da ordem.",
          variant: "destructive",
        })
      }
    }
  }

  const handleTxidSubmit = async (txid) => {
    try {
      const { error } = await supabase
        .from("orders")
        .update({
          status: "processing",
          status_text: "Processando",
          txid: txid,
          updated_at: new Date().toISOString(),
        })
        .eq("id", selectedOrderId)

      if (error) throw error

      setOrders(
        orders.map((order) => {
          if (order.id === selectedOrderId) {
            return {
              ...order,
              status: "processing",
              status_text: "Processando",
              txid: txid,
              updated_at: new Date().toISOString(),
            }
          }
          return order
        }),
      )

      setShowTxidModal(false)
      toast({
        title: "Ordem atualizada",
        description: "A ordem foi marcada como 'Processando' e o TXID foi adicionado.",
      })
    } catch (error) {
      console.error("Erro ao atualizar ordem:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao atualizar a ordem.",
        variant: "destructive",
      })
    }
  }

  const copyShareLink = (e, orderId) => {
    e.stopPropagation()
    const shareUrl = `${window.location.origin}/order/${orderId}`
    navigator.clipboard.writeText(shareUrl)
    toast({
      title: "Link copiado",
      description: "O link para compartilhar foi copiado para a área de transferência.",
    })
  }

  const toggleOrderExpand = (orderId) => {
    setExpandedOrders((prev) => ({
      ...prev,
      [orderId]: !prev[orderId],
    }))
  }

  const handleLogout = () => {
    localStorage.removeItem("authenticated")
    router.push("/login")
  }

  const handleTabChange = async (value) => {
    setActiveTab(value)

    if (value === "requests") {
      // Marcar todos os pedidos como vistos
      try {
        const { error } = await supabase.from("order_requests").update({ seen: true }).eq("seen", false)

        if (error) throw error

        setOrderRequests(
          orderRequests.map((req) => ({
            ...req,
            seen: true,
          })),
        )

        setHasNewRequests(false)
        setShowNotification(false)
      } catch (error) {
        console.error("Erro ao atualizar pedidos:", error)
      }
    }
  }

  const handleCreateFromRequest = (request) => {
    setSelectedRequest(request)
    setShowCreateFromRequestModal(true)
  }

  const handleOrderCreated = async (newOrder) => {
    try {
      // Adicionar nova ordem
      const { data: orderData, error: orderError } = await supabase
        .from("orders")
        .insert({
          seller_id: newOrder.seller_id,
          seller_name: newOrder.seller_name,
          store: newOrder.store,
          client_id: newOrder.client_id,
          client_name: newOrder.client_name,
          amount_usd: newOrder.amount_usd,
          amount_brl: newOrder.amount_brl,
          payment_code: newOrder.payment_code,
          wallet: newOrder.wallet,
          notes: newOrder.notes,
          status: "pending",
          status_text: "Aguardando Pagamento",
          expiration_time: newOrder.expiration_time,
        })
        .select()
        .single()

      if (orderError) throw orderError

      // Remover o pedido
      const { error: deleteError } = await supabase.from("order_requests").delete().eq("id", selectedRequest.id)

      if (deleteError) throw deleteError

      setShowCreateFromRequestModal(false)

      // Atualizar listas locais
      setOrders([orderData, ...orders])
      setOrderRequests(orderRequests.filter((req) => req.id !== selectedRequest.id))

      toast({
        title: "Ordem criada",
        description: "A ordem foi criada com sucesso a partir do pedido.",
      })
    } catch (error) {
      console.error("Erro ao criar ordem:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao criar a ordem.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteRequest = async (requestId) => {
    try {
      const { error } = await supabase.from("order_requests").delete().eq("id", requestId)

      if (error) throw error

      setOrderRequests(orderRequests.filter((req) => req.id !== requestId))

      toast({
        title: "Pedido excluído",
        description: "O pedido foi excluído com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao excluir pedido:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao excluir o pedido.",
        variant: "destructive",
      })
    }
  }

  const handleAddSeller = async (seller) => {
    try {
      // Adicionar vendedora
      const { data: sellerData, error: sellerError } = await supabase
        .from("sellers")
        .insert({
          name: seller.name,
          store: seller.store,
        })
        .select()
        .single()

      if (sellerError) throw sellerError

      // Verificar se a loja já existe no financeiro
      const { data: financeData, error: financeCheckError } = await supabase
        .from("finances")
        .select("id")
        .eq("store", seller.store)
        .maybeSingle()

      if (financeCheckError) throw financeCheckError

      // Se a loja não existir, criar um novo painel financeiro
      if (!financeData) {
        const { error: financeError } = await supabase.from("finances").insert({
          store: seller.store,
        })

        if (financeError) throw financeError
      }

      toast({
        title: "Vendedora adicionada",
        description: `${seller.name} foi adicionada com sucesso.`,
      })

      setShowAddSellerModal(false)
    } catch (error) {
      console.error("Erro ao adicionar vendedora:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao adicionar a vendedora.",
        variant: "destructive",
      })
    }
  }

  const handleDismissNotification = () => {
    setShowNotification(false)
  }

  const handleNotificationClick = () => {
    setActiveTab("requests")
    setShowNotification(false)
  }

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "converting":
        return "warning"
      case "processing":
        return "primary"
      case "awaiting_release":
        return "default"
      case "released":
        return "success"
      case "expired":
        return "destructive"
      default:
        return "secondary"
    }
  }

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  return (
    <div className="container mx-auto py-4 px-4">
      {/* Notificação de novos pedidos */}
      <NotificationAlert
        show={showNotification}
        message={`Você recebeu ${newRequestsCount} ${newRequestsCount === 1 ? "novo pedido" : "novos pedidos"} de ordem.`}
        count={newRequestsCount}
        onDismiss={handleDismissNotification}
        onClick={handleNotificationClick}
      />

      <div className="flex justify-between items-center mb-4">
        <div className="flex flex-col">
          <h1 className="text-2xl font-bold">Ordens de Pagamento</h1>
          <RefreshIndicator lastRefresh={lastRefresh} isRefreshing={isRefreshing} />
        </div>
        <div className="flex gap-2">
          <div className="flex gap-2">
            <Link href="/sellers">
              <Button variant="outline">
                <Users className="mr-2 h-4 w-4" /> Listar Vendedoras
              </Button>
            </Link>
            <Link href="/finances">
              <Button variant="outline">
                <Building className="mr-2 h-4 w-4" /> Listar Financeiro
              </Button>
            </Link>
            <Link href="/orders-list">
              <Button variant="outline">
                <Activity className="mr-2 h-4 w-4" /> Ordens Listadas
              </Button>
            </Link>
            <Link href="/diagnostico">
              <Button variant="outline">
                <Activity className="mr-2 h-4 w-4" /> Diagnóstico
              </Button>
            </Link>
          </div>
          <Link href="/create-order">
            <Button>
              <Plus className="mr-2 h-4 w-4" /> Nova Ordem
            </Button>
          </Link>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" /> Sair
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange}>
        <TabsList className="mb-4">
          <TabsTrigger value="orders">Ordens</TabsTrigger>
          <TabsTrigger value="requests" className="relative">
            Pedidos de Ordem
            {hasNewRequests && (
              <span className="absolute -top-1 -right-1">
                <Badge
                  variant="destructive"
                  className="h-5 w-5 p-0 flex items-center justify-center rounded-full animate-pulse"
                >
                  <Bell className="h-3 w-3" />
                </Badge>
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          {Object.keys(groupedOrders).length === 0 ? (
            <Card>
              <CardContent className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Nenhuma ordem encontrada. Crie uma nova ordem para começar.</p>
              </CardContent>
            </Card>
          ) : (
            Object.entries(groupedOrders)
              .sort(([dateA], [dateB]) => {
                const [dayA, monthA, yearA] = dateA.split("/").map(Number)
                const [dayB, monthB, yearB] = dateB.split("/").map(Number)
                return new Date(yearB, monthB - 1, dayB) - new Date(yearA, monthA - 1, dayA)
              })
              .map(([date, dateOrders]) => (
                <div key={date} className="mb-4">
                  <h2 className="text-md font-semibold mb-2">{date}</h2>
                  <div className="space-y-2">
                    {dateOrders.map((order) => (
                      <Card
                        key={order.id}
                        className={`overflow-hidden cursor-pointer transition-all ${
                          order.status === "released"
                            ? "border-green-500 bg-green-50"
                            : order.status === "expired"
                              ? "border-red-500 bg-red-50"
                              : ""
                        }`}
                        onClick={() => toggleOrderExpand(order.id)}
                      >
                        <CardContent className="p-3">
                          {/* Cabeçalho compacto - sempre visível */}
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              {expandedOrders[order.id] ? (
                                <ChevronUp className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <ChevronDown className="h-4 w-4 text-muted-foreground" />
                              )}
                              <div>
                                <div className="flex items-center gap-1">
                                  <span className="font-medium">{order.client_id}</span>
                                  <span className="font-medium">-</span>
                                  <span className="font-medium">{order.client_name}</span>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {order.seller_name} / {order.store}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-bold">${Number.parseFloat(order.amount_usd).toFixed(2)}</p>
                              <p className="text-xs">R$ {Number.parseFloat(order.amount_brl).toFixed(2)}</p>
                            </div>
                          </div>

                          {/* Conteúdo expandido - visível apenas quando expandido */}
                          {expandedOrders[order.id] && (
                            <div className="mt-3 pt-3 border-t">
                              <div className="text-sm mb-2">
                                {order.wallet && <p className="truncate">Carteira: {order.wallet}</p>}
                                <div className="flex items-center mt-1">
                                  <Badge variant={getStatusBadgeVariant(order.status)} className="mr-2">
                                    {order.status_text || "Aguardando Pagamento"}
                                  </Badge>
                                  {order.txid && (
                                    <a
                                      href={`http://tronscan.org/#/transaction/${order.txid}`}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-xs text-blue-600 hover:underline inline-flex items-center"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      Ver transação <ExternalLink className="h-3 w-3 ml-1" />
                                    </a>
                                  )}
                                </div>
                              </div>

                              {order.notes && (
                                <div className="bg-gray-50 p-2 rounded-md mb-3 text-sm">
                                  <p className="font-medium text-xs mb-1">Notas:</p>
                                  {order.notes.split("\n").map((note, i) => (
                                    <p key={i} className="text-sm">
                                      {note}
                                    </p>
                                  ))}
                                </div>
                              )}

                              <div className="flex flex-wrap gap-2 mt-3">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex-1"
                                  onClick={(e) => copyShareLink(e, order.id)}
                                >
                                  <Share2 className="h-4 w-4 mr-1" /> Compartilhar
                                </Button>

                                <Link
                                  href={`/order/${order.id}`}
                                  className="flex-1"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <Button variant="outline" size="sm" className="w-full">
                                    <ExternalLink className="h-4 w-4 mr-1" /> Ver
                                  </Button>
                                </Link>

                                {order.status === "pending" && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="flex-1"
                                    onClick={(e) => handleConvertingClick(e, order.id)}
                                  >
                                    <DollarSign className="h-4 w-4 mr-1" /> Convertendo
                                  </Button>
                                )}

                                {(order.status === "pending" || order.status === "converting") && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="flex-1"
                                    onClick={(e) => handleMarkAsPaidClick(e, order.id)}
                                  >
                                    <CheckCircle className="h-4 w-4 mr-1" /> Pago
                                  </Button>
                                )}

                                <Button
                                  variant="destructive"
                                  size="sm"
                                  className="flex-shrink-0"
                                  onClick={(e) => handleDeleteClick(e, order.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))
          )}
        </TabsContent>

        <TabsContent value="requests">
          {orderRequests.length === 0 ? (
            <Card>
              <CardContent className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Nenhum pedido de ordem encontrado.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {orderRequests.map((request) => (
                <Card key={request.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="flex items-center gap-1">
                          <span className="font-medium">{request.client_id}</span>
                          <span className="font-medium">-</span>
                          <span className="font-medium">{request.client_name}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {request.seller_name} / {request.store}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${Number.parseFloat(request.amount_usd).toFixed(2)}</p>
                        <p className="text-xs">R$ {Number.parseFloat(request.amount_brl).toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(request.created_at).toLocaleString("pt-BR")}
                        </p>
                      </div>
                    </div>

                    {request.notes && (
                      <div className="bg-gray-50 p-2 rounded-md mb-3 text-sm">
                        <p className="font-medium text-xs mb-1">Notas:</p>
                        {request.notes.split("\n").map((note, i) => (
                          <p key={i} className="text-sm">
                            {note}
                          </p>
                        ))}
                      </div>
                    )}

                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" size="sm" onClick={() => handleDeleteRequest(request.id)}>
                        <Trash2 className="h-4 w-4 mr-1" /> Recusar
                      </Button>
                      <Button size="sm" onClick={() => handleCreateFromRequest(request)}>
                        <Plus className="h-4 w-4 mr-1" /> Criar Ordem
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {showPinModal && (
        <PinModal
          onClose={() => setShowPinModal(false)}
          onPinVerified={handlePinVerified}
          action={
            actionType === "delete"
              ? "excluir"
              : actionType === "converting"
                ? "marcar como convertendo"
                : "marcar como pago"
          }
        />
      )}

      {showTxidModal && <TxidModal onClose={() => setShowTxidModal(false)} onSubmit={handleTxidSubmit} />}

      {showCreateFromRequestModal && selectedRequest && (
        <CreateOrderFromRequestModal
          request={selectedRequest}
          onClose={() => setShowCreateFromRequestModal(false)}
          onOrderCreated={handleOrderCreated}
        />
      )}

      {showAddSellerModal && (
        <AddSellerModal onClose={() => setShowAddSellerModal(false)} onAddSeller={handleAddSeller} />
      )}

      <Toaster />
    </div>
  )
}
