"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Loader2, CheckCircle2, AlertTriangle, Info } from "lucide-react"
import { createClient } from "@/utils/supabase/client"

export default function DiagnosticTool() {
  const [isRunning, setIsRunning] = useState(false)
  const [results, setResults] = useState([])
  const [summary, setSummary] = useState({ success: 0, warning: 0, error: 0 })
  const supabase = createClient()

  const runDiagnostics = async () => {
    setIsRunning(true)
    setResults([])
    setSummary({ success: 0, warning: 0, error: 0 })

    try {
      // Adicionar mensagem de início
      addResult("info", "Iniciando diagnóstico do sistema...")

      // 1. Verificar conexão com o banco de dados
      await checkDatabaseConnection()

      // 2. Verificar tabelas e estrutura
      await checkDatabaseStructure()

      // 3. Verificar ordens expiradas
      await checkExpiredOrders()

      // 4. Verificar inconsistências de status
      await checkStatusConsistency()

      // 5. Verificar pedidos não vistos
      await checkUnseenRequests()

      // Adicionar mensagem de conclusão
      addResult("info", "Diagnóstico concluído.")
    } catch (error) {
      console.error("Erro durante o diagnóstico:", error)
      addResult("error", `Erro durante o diagnóstico: ${error.message}`)
    } finally {
      setIsRunning(false)
    }
  }

  const addResult = (type, message, details = null) => {
    const newResult = {
      id: Date.now(),
      type,
      message,
      details,
      timestamp: new Date().toISOString(),
    }

    setResults((prev) => [...prev, newResult])
    setSummary((prev) => ({
      ...prev,
      [type]: prev[type] + 1,
    }))
  }

  const checkDatabaseConnection = async () => {
    try {
      addResult("info", "Verificando conexão com o banco de dados...")

      const startTime = performance.now()
      const { data, error } = await supabase.from("orders").select("count(*)", { count: "exact" }).limit(1)
      const endTime = performance.now()

      if (error) {
        addResult("error", `Falha na conexão com o banco de dados: ${error.message}`)
        return
      }

      const responseTime = Math.round(endTime - startTime)

      if (responseTime > 1000) {
        addResult(
          "warning",
          `Conexão com o banco de dados estabelecida, mas com tempo de resposta alto: ${responseTime}ms`,
        )
      } else {
        addResult("success", `Conexão com o banco de dados estabelecida com sucesso (${responseTime}ms)`)
      }
    } catch (error) {
      addResult("error", `Erro ao verificar conexão com o banco de dados: ${error.message}`)
    }
  }

  const checkDatabaseStructure = async () => {
    try {
      addResult("info", "Verificando estrutura do banco de dados...")

      // Verificar tabela orders
      const { data: ordersColumns, error: ordersError } = await supabase
        .from("information_schema.columns")
        .select("column_name")
        .eq("table_schema", "public")
        .eq("table_name", "orders")

      if (ordersError) {
        addResult("error", `Erro ao verificar estrutura da tabela orders: ${ordersError.message}`)
        return
      }

      const requiredOrderColumns = [
        "id",
        "created_at",
        "updated_at",
        "seller_id",
        "seller_name",
        "store",
        "client_id",
        "client_name",
        "amount_usd",
        "amount_brl",
        "status",
        "status_text",
        "payment_code",
        "expiration_time",
      ]

      const missingColumns = requiredOrderColumns.filter((col) => !ordersColumns.some((c) => c.column_name === col))

      if (missingColumns.length > 0) {
        addResult("error", `Colunas ausentes na tabela orders: ${missingColumns.join(", ")}`)
      } else {
        addResult("success", "Estrutura da tabela orders verificada com sucesso")
      }

      // Verificar índices
      const { data: indices, error: indicesError } = await supabase
        .from("pg_indexes")
        .select("indexname, indexdef")
        .eq("schemaname", "public")
        .eq("tablename", "orders")

      if (indicesError) {
        addResult("error", `Erro ao verificar índices: ${indicesError.message}`)
        return
      }

      const hasExpirationIndex = indices.some(
        (idx) => idx.indexname.includes("expiration_time") || idx.indexdef.includes("expiration_time"),
      )

      if (!hasExpirationIndex) {
        addResult("warning", "Índice para o campo expiration_time não encontrado")
      } else {
        addResult("success", "Índices verificados com sucesso")
      }
    } catch (error) {
      addResult("error", `Erro ao verificar estrutura do banco de dados: ${error.message}`)
    }
  }

  const checkExpiredOrders = async () => {
    try {
      addResult("info", "Verificando ordens expiradas...")

      const now = new Date().toISOString()

      // Verificar ordens que deveriam estar expiradas
      const { data, error } = await supabase
        .from("orders")
        .select("id")
        .eq("status", "pending")
        .lt("expiration_time", now)

      if (error) {
        addResult("error", `Erro ao verificar ordens expiradas: ${error.message}`)
        return
      }

      if (data && data.length > 0) {
        addResult("warning", `Encontradas ${data.length} ordens que deveriam estar expiradas`, {
          count: data.length,
          orderIds: data.map((o) => o.id),
        })
      } else {
        addResult("success", "Nenhuma ordem expirada encontrada")
      }
    } catch (error) {
      addResult("error", `Erro ao verificar ordens expiradas: ${error.message}`)
    }
  }

  const checkStatusConsistency = async () => {
    try {
      addResult("info", "Verificando consistência de status...")

      const { data, error } = await supabase.from("orders").select("id, status, status_text")

      if (error) {
        addResult("error", `Erro ao verificar consistência de status: ${error.message}`)
        return
      }

      const inconsistentOrders = data.filter((order) => {
        let correctStatusText = ""

        switch (order.status) {
          case "pending":
            correctStatusText = "Aguardando Pagamento"
            break
          case "converting":
            correctStatusText = "Convertendo Dinheiro"
            break
          case "processing":
            correctStatusText = "Processando"
            break
          case "awaiting_release":
            correctStatusText = "Aguardando Liberação"
            break
          case "released":
            correctStatusText = "Pedido Liberado"
            break
          case "expired":
            correctStatusText = "Pagamento Expirado"
            break
        }

        return order.status_text !== correctStatusText
      })

      if (inconsistentOrders.length > 0) {
        addResult("warning", `Encontradas ${inconsistentOrders.length} ordens com status inconsistente`, {
          count: inconsistentOrders.length,
          orders: inconsistentOrders,
        })
      } else {
        addResult("success", "Todos os status estão consistentes")
      }
    } catch (error) {
      addResult("error", `Erro ao verificar consistência de status: ${error.message}`)
    }
  }

  const checkUnseenRequests = async () => {
    try {
      addResult("info", "Verificando pedidos não vistos...")

      const { data, error } = await supabase
        .from("order_requests")
        .select("id, created_at")
        .eq("seen", false)
        .order("created_at", { ascending: false })

      if (error) {
        addResult("error", `Erro ao verificar pedidos não vistos: ${error.message}`)
        return
      }

      if (data && data.length > 0) {
        // Verificar se há pedidos antigos (mais de 24 horas)
        const oneDayAgo = new Date()
        oneDayAgo.setDate(oneDayAgo.getDate() - 1)

        const oldRequests = data.filter((req) => new Date(req.created_at) < oneDayAgo)

        if (oldRequests.length > 0) {
          addResult("warning", `Encontrados ${oldRequests.length} pedidos antigos não vistos`, {
            count: oldRequests.length,
            requestIds: oldRequests.map((r) => r.id),
          })
        } else {
          addResult("info", `Existem ${data.length} pedidos não vistos`)
        }
      } else {
        addResult("success", "Não há pedidos não vistos")
      }
    } catch (error) {
      addResult("error", `Erro ao verificar pedidos não vistos: ${error.message}`)
    }
  }

  const fixExpiredOrders = async () => {
    try {
      setIsRunning(true)
      addResult("info", "Corrigindo ordens expiradas...")

      const now = new Date().toISOString()

      const { data, error } = await supabase
        .from("orders")
        .update({
          status: "expired",
          status_text: "Pagamento Expirado",
          updated_at: now,
        })
        .eq("status", "pending")
        .lt("expiration_time", now)
        .select()

      if (error) {
        addResult("error", `Erro ao corrigir ordens expiradas: ${error.message}`)
        return
      }

      if (data && data.length > 0) {
        addResult("success", `${data.length} ordens foram atualizadas para expiradas`)
      } else {
        addResult("info", "Nenhuma ordem precisava ser atualizada")
      }
    } catch (error) {
      addResult("error", `Erro ao corrigir ordens expiradas: ${error.message}`)
    } finally {
      setIsRunning(false)
    }
  }

  const getStatusIcon = (type) => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-amber-500" />
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case "info":
        return <Info className="h-4 w-4 text-blue-500" />
      default:
        return <Info className="h-4 w-4" />
    }
  }

  const getStatusColor = (type) => {
    switch (type) {
      case "success":
        return "text-green-600"
      case "warning":
        return "text-amber-600"
      case "error":
        return "text-red-600"
      case "info":
        return "text-blue-600"
      default:
        return ""
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl flex items-center justify-between">
          <span>Diagnóstico do Sistema</span>
          <Button onClick={runDiagnostics} disabled={isRunning}>
            {isRunning ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Executando...
              </>
            ) : (
              "Executar Diagnóstico"
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {results.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Clique em "Executar Diagnóstico" para verificar a saúde do sistema
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex gap-3 justify-center mb-4">
              <Badge variant="outline" className="flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3 text-green-500" />
                <span>{summary.success} Sucessos</span>
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-amber-500" />
                <span>{summary.warning} Avisos</span>
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3 text-red-500" />
                <span>{summary.error} Erros</span>
              </Badge>
            </div>

            <div className="border rounded-md p-4 max-h-96 overflow-y-auto">
              {results.map((result) => (
                <div key={result.id} className="mb-2 last:mb-0">
                  <div className="flex items-start gap-2">
                    {getStatusIcon(result.type)}
                    <div>
                      <p className={`text-sm ${getStatusColor(result.type)}`}>{result.message}</p>
                      {result.details && (
                        <pre className="text-xs bg-gray-50 p-2 mt-1 rounded overflow-x-auto">
                          {JSON.stringify(result.details, null, 2)}
                        </pre>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {results.some((r) => r.type === "warning" && r.message.includes("expiradas")) && (
              <div className="flex justify-end">
                <Button onClick={fixExpiredOrders} disabled={isRunning} variant="secondary" size="sm">
                  {isRunning ? (
                    <>
                      <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                      Corrigindo...
                    </>
                  ) : (
                    "Corrigir Ordens Expiradas"
                  )}
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
