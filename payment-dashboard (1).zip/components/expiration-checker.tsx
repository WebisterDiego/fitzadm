"use client"

import { useEffect, useState, useRef } from "react"
import { createClient } from "@/utils/supabase/client"

export default function ExpirationChecker() {
  const [lastCheck, setLastCheck] = useState<Date | null>(null)
  const isRunningRef = useRef(false)
  const supabase = createClient()

  useEffect(() => {
    // Função para verificar e atualizar ordens expiradas
    const checkExpiredOrders = async () => {
      // Evitar execuções simultâneas
      if (isRunningRef.current) return
      isRunningRef.current = true

      try {
        const now = new Date()
        setLastCheck(now)

        // Atualizar ordens expiradas
        const { data, error } = await supabase
          .from("orders")
          .update({
            status: "expired",
            status_text: "Pagamento Expirado",
            updated_at: now.toISOString(),
          })
          .eq("status", "pending")
          .lt("expiration_time", now.toISOString())
          .select()

        if (error) {
          console.error("Erro ao atualizar ordens expiradas:", error)
          return
        }

        if (data && data.length > 0) {
          console.log(`[ExpirationChecker] ${data.length} ordens foram marcadas como expiradas`)
        }
      } catch (error) {
        console.error("[ExpirationChecker] Erro ao verificar ordens expiradas:", error)
      } finally {
        isRunningRef.current = false
      }
    }

    // Verificar imediatamente ao montar o componente
    checkExpiredOrders()

    // Configurar verificação periódica
    const interval = setInterval(checkExpiredOrders, 30000) // A cada 30 segundos

    return () => clearInterval(interval)
  }, [supabase])

  // Este componente não renderiza nada visível
  return null
}
