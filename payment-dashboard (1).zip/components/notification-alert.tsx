"use client"

import { useState, useEffect, useRef } from "react"
import { Bell, X } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

interface NotificationAlertProps {
  show: boolean
  message: string
  count: number
  onDismiss: () => void
  onClick: () => void
}

export default function NotificationAlert({ show, message, count, onDismiss, onClick }: NotificationAlertProps) {
  const [isVisible, setIsVisible] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Criar elemento de áudio para o som de notificação
    audioRef.current = new Audio("/notification-sound.mp3")

    return () => {
      // Limpar referência ao desmontar
      audioRef.current = null
    }
  }, [])

  useEffect(() => {
    if (show) {
      setIsVisible(true)
      // Tocar som de notificação
      if (audioRef.current) {
        audioRef.current.volume = 0.5
        audioRef.current.play().catch((err) => {
          // Ignorar erros de reprodução automática (políticas de navegador)
          console.log("Reprodução automática bloqueada pelo navegador")
        })
      }
    } else {
      setIsVisible(false)
    }
  }, [show])

  if (!isVisible) return null

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          className="fixed top-4 right-4 z-50 max-w-md"
        >
          <Card className="bg-primary text-primary-foreground p-4 shadow-lg border-none">
            <div className="flex items-start gap-3">
              <div className="bg-primary-foreground text-primary rounded-full p-2 flex-shrink-0">
                <Bell className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium mb-1">Novo(s) Pedido(s) de Ordem</h4>
                <p className="text-sm opacity-90">{message}</p>
                <div className="mt-3 flex justify-end gap-2">
                  <Button variant="secondary" size="sm" className="text-xs" onClick={onDismiss}>
                    Dispensar
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-xs"
                    onClick={onClick}
                  >
                    Ver Pedidos ({count})
                  </Button>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded-full text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary/80"
                onClick={onDismiss}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
