"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { createClient } from "@/utils/supabase/client"

interface PinModalProps {
  onClose: () => void
  onPinVerified: () => void
  action: string
}

export default function PinModal({ onClose, onPinVerified, action }: PinModalProps) {
  const [pin, setPin] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  const handleVerify = async () => {
    setIsLoading(true)
    setError("")

    try {
      // Buscar o PIN de segurança do banco de dados
      const { data: securitySettings, error: fetchError } = await supabase
        .from("security_settings")
        .select("security_pin")
        .single()

      if (fetchError) {
        throw new Error("Erro ao buscar configurações de segurança")
      }

      const storedPin = securitySettings?.security_pin || "99668526"

      if (pin === storedPin) {
        onPinVerified()
      } else {
        setError("PIN inválido. Tente novamente.")
      }
    } catch (error) {
      console.error("Erro ao verificar PIN:", error)
      setError("Ocorreu um erro ao verificar o PIN. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Verificação de PIN</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <p>Digite o PIN para {action} esta ordem.</p>
          <Input
            id="pin"
            type="password"
            placeholder="Digite o PIN"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            className="text-center text-xl tracking-widest"
            maxLength={8}
          />
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleVerify} disabled={isLoading}>
            {isLoading ? "Verificando..." : "Verificar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
