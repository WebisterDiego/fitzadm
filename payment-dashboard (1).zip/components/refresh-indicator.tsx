"use client"

import { useState, useEffect } from "react"
import { RefreshCw } from "lucide-react"

interface RefreshIndicatorProps {
  lastRefresh: Date
  isRefreshing?: boolean
}

export default function RefreshIndicator({ lastRefresh, isRefreshing = false }: RefreshIndicatorProps) {
  const [timeAgo, setTimeAgo] = useState("")

  useEffect(() => {
    // Atualizar o tempo desde a última atualização a cada segundo
    const updateTimeAgo = () => {
      const now = new Date()
      const diffSeconds = Math.floor((now.getTime() - lastRefresh.getTime()) / 1000)

      if (diffSeconds < 5) {
        setTimeAgo("agora")
      } else if (diffSeconds < 60) {
        setTimeAgo(`${diffSeconds} segundos atrás`)
      } else {
        const diffMinutes = Math.floor(diffSeconds / 60)
        setTimeAgo(`${diffMinutes} ${diffMinutes === 1 ? "minuto" : "minutos"} atrás`)
      }
    }

    updateTimeAgo()
    const interval = setInterval(updateTimeAgo, 1000)

    return () => clearInterval(interval)
  }, [lastRefresh])

  return (
    <div className="flex items-center text-xs text-muted-foreground">
      <RefreshCw className={`h-3 w-3 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
      <span>Atualizado: {timeAgo}</span>
    </div>
  )
}
