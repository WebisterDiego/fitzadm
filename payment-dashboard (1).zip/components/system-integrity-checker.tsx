"use client"

import { useEffect, useRef } from "react"
import { createClient } from "@/utils/supabase/client"

export default function SystemIntegrityChecker() {
  const supabase = createClient()
  const lastCheckRef = useRef<Date | null>(null)
  const isRunningRef = useRef(false)

  useEffect(() => {
    // Função para verificar e corrigir problemas no sistema
    const checkSystemIntegrity = async () => {
      // Evitar execuções simultâneas
      if (isRunningRef.current) return
      isRunningRef.current = true

      try {
        // Registrar o momento da verificação
        lastCheckRef.current = new Date()
        console.log(`[Sistema] Verificação de integridade iniciada: ${lastCheckRef.current.toISOString()}`)

        // 1. Verificar e corrigir ordens expiradas
        await fixExpiredOrders()

        // 2. Verificar e corrigir inconsistências de status
        await fixStatusInconsistencies()

        // 3. Verificar e corrigir pedidos órfãos
        await fixOrphanRequests()

        console.log(`[Sistema] Verificação de integridade concluída`)
      } catch (error) {
        console.error("[Sistema] Erro na verificação de integridade:", error)
      } finally {
        isRunningRef.current = false
      }
    }

    // Função para corrigir ordens expiradas
    const fixExpiredOrders = async () => {
      try {
        const now = new Date().toISOString()

        // Buscar ordens pendentes que já passaram do tempo de expiração
        const { data, error } = await supabase
          .from("orders")
          .update({
            status: "expired",
            status_text: "Pagamento Expirado",
            updated_at: now,
          })
          .eq("status", "pending")
          .lt("expiration_time", now)
          .select()

        if (error) throw error

        if (data && data.length > 0) {
          console.log(`[Sistema] ${data.length} ordens foram marcadas como expiradas`)
        }
      } catch (error) {
        console.error("[Sistema] Erro ao corrigir ordens expiradas:", error)
      }
    }

    // Função para corrigir inconsistências de status
    const fixStatusInconsistencies = async () => {
      try {
        // Verificar ordens com status_text inconsistente com status
        const { data: inconsistentOrders, error: fetchError } = await supabase
          .from("orders")
          .select("id, status, status_text")

        if (fetchError) throw fetchError

        if (inconsistentOrders) {
          const updates = []

          for (const order of inconsistentOrders) {
            let correctStatusText = ""

            switch (order.status) {
              case "pending":
                correctStatusText = "Aguardando Pagamento"
                break
              case "converting":
                correctStatusText = "Convertendo Dinheiro"
                break
              case "processing":
                correctStatusText = "Processando"
                break
              case "awaiting_release":
                correctStatusText = "Aguardando Liberação"
                break
              case "released":
                correctStatusText = "Pedido Liberado"
                break
              case "expired":
                correctStatusText = "Pagamento Expirado"
                break
            }

            // Se o status_text estiver incorreto, adicionar à lista de atualizações
            if (order.status_text !== correctStatusText) {
              updates.push({
                id: order.id,
                status_text: correctStatusText,
              })
            }
          }

          // Atualizar ordens com status_text incorreto
          if (updates.length > 0) {
            for (const update of updates) {
              await supabase
                .from("orders")
                .update({ status_text: update.status_text, updated_at: new Date().toISOString() })
                .eq("id", update.id)
            }

            console.log(`[Sistema] ${updates.length} ordens tiveram o status_text corrigido`)
          }
        }
      } catch (error) {
        console.error("[Sistema] Erro ao corrigir inconsistências de status:", error)
      }
    }

    // Função para corrigir pedidos órfãos (pedidos antigos que nunca foram vistos)
    const fixOrphanRequests = async () => {
      try {
        // Buscar pedidos antigos (mais de 7 dias) que nunca foram vistos
        const sevenDaysAgo = new Date()
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

        const { data, error } = await supabase
          .from("order_requests")
          .update({ seen: true })
          .eq("seen", false)
          .lt("created_at", sevenDaysAgo.toISOString())
          .select()

        if (error) throw error

        if (data && data.length > 0) {
          console.log(`[Sistema] ${data.length} pedidos antigos foram marcados como vistos`)
        }
      } catch (error) {
        console.error("[Sistema] Erro ao corrigir pedidos órfãos:", error)
      }
    }

    // Executar verificação imediatamente
    checkSystemIntegrity()

    // Configurar verificação periódica (a cada 5 minutos)
    const interval = setInterval(checkSystemIntegrity, 5 * 60 * 1000)

    return () => clearInterval(interval)
  }, [supabase])

  // Este componente não renderiza nada visível
  return null
}
