"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"

interface TxidModalProps {
  onClose: () => void
  onSubmit: (txid: string) => void
}

export default function TxidModal({ onClose, onSubmit }: TxidModalProps) {
  const [txid, setTxid] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = () => {
    if (!txid.trim()) {
      setError("Por favor, insira o TXID da transação.")
      return
    }

    setIsLoading(true)
    onSubmit(txid)
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Adicionar TXID da Transação</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <p>Insira o TXID da transação para marcar esta ordem como paga.</p>
          <p className="text-sm text-muted-foreground">
            O link completo será: http://tronscan.org/#/transaction/{txid || "seu-txid"}
          </p>
          <Input id="txid" placeholder="TXID da transação" value={txid} onChange={(e) => setTxid(e.target.value)} />
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? "Confirmando..." : "Confirmar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
