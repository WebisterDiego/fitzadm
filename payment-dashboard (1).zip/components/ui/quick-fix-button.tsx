"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

interface QuickFixButtonProps {
  label: string
  fixFunction: () => Promise<{ success: boolean; message: string }>
  onComplete?: (success: boolean) => void
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
}

export function QuickFixButton({ label, fixFunction, onComplete, variant = "default" }: QuickFixButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  const handleClick = async () => {
    setIsLoading(true)

    try {
      const result = await fixFunction()

      if (result.success) {
        toast({
          title: "Operação concluída",
          description: result.message,
        })
      } else {
        toast({
          title: "Erro",
          description: result.message,
          variant: "destructive",
        })
      }

      if (onComplete) {
        onComplete(result.success)
      }
    } catch (error) {
      console.error("Erro ao executar correção:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao executar a operação",
        variant: "destructive",
      })

      if (onComplete) {
        onComplete(false)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button variant={variant} onClick={handleClick} disabled={isLoading}>
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Processando...
        </>
      ) : (
        label
      )}
    </Button>
  )
}
