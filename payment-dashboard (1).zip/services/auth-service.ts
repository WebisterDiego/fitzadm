"use server"

import { createClient } from "@/utils/supabase/server"

export async function verifyPin(pin: string) {
  const supabase = createClient()

  const { data, error } = await supabase.from("security_settings").select("security_pin").single()

  if (error) {
    console.error("Erro ao verificar PIN:", error)
    return false
  }

  return data.security_pin === pin
}
