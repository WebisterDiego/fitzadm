"use server"

import { createClient } from "@/utils/supabase/server"

export async function updateExpiredOrders() {
  const supabase = createClient()

  try {
    const now = new Date().toISOString()

    // Atualizar todas as ordens pendentes que já expiraram
    const { data, error } = await supabase
      .from("orders")
      .update({
        status: "expired",
        status_text: "Pagamento Expirado",
        updated_at: now,
      })
      .eq("status", "pending")
      .lt("expiration_time", now)
      .select()

    if (error) {
      console.error("Erro ao atualizar ordens expiradas:", error)
      return { success: false, count: 0, error: error.message }
    }

    return { success: true, count: data.length }
  } catch (error) {
    console.error("Erro ao processar ordens expiradas:", error)
    return { success: false, count: 0, error: String(error) }
  }
}

// Esta função pode ser chamada por um cron job ou webhook
export async function checkAndUpdateExpiredOrders() {
  return await updateExpiredOrders()
}
