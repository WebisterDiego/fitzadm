"use server"

import { createClient } from "@/utils/supabase/server"

export async function getAllFinances() {
  const supabase = createClient()

  const { data, error } = await supabase.from("finances").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar painéis financeiros:", error)
    return []
  }

  return data
}

export async function getFinanceByStore(store: string) {
  const supabase = createClient()

  const { data, error } = await supabase.from("finances").select("*").eq("store", store).single()

  if (error) {
    console.error("Erro ao buscar painel financeiro:", error)
    return null
  }

  return data
}
