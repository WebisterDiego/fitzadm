"use server"

import { createClient } from "@/utils/supabase/server"

export async function getAllOrderRequests() {
  const supabase = createClient()

  const { data, error } = await supabase.from("order_requests").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar pedidos de ordens:", error)
    return []
  }

  return data
}

export async function createOrderRequest(request: any) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("order_requests")
    .insert([
      {
        seller_id: request.sellerId,
        seller_name: request.seller,
        store: request.store,
        client_id: request.clientId,
        client_name: request.clientName,
        amount_usd: request.amountUSD,
        amount_brl: request.amountBRL,
        wallet: request.wallet,
        notes: request.notes,
        seen: false,
      },
    ])
    .select()

  if (error) {
    console.error("Erro ao criar pedido de ordem:", error)
    return null
  }

  return data[0]
}

export async function markOrderRequestsAsSeen() {
  const supabase = createClient()

  const { error } = await supabase.from("order_requests").update({ seen: true }).eq("seen", false)

  if (error) {
    console.error("Erro ao marcar pedidos como vistos:", error)
    return false
  }

  return true
}

export async function deleteOrderRequest(id: string) {
  const supabase = createClient()

  const { error } = await supabase.from("order_requests").delete().eq("id", id)

  if (error) {
    console.error("Erro ao excluir pedido de ordem:", error)
    return false
  }

  return true
}
