"use server"

import { createClient } from "@/utils/supabase/server"

export async function getAllOrders() {
  const supabase = createClient()

  const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar ordens:", error)
    return []
  }

  return data
}

export async function getOrderById(id: string) {
  const supabase = createClient()

  const { data, error } = await supabase.from("orders").select("*").eq("id", id).single()

  if (error) {
    console.error("Erro ao buscar ordem:", error)
    return null
  }

  return data
}

export async function getOrdersBySellerAndStore(sellerName: string, store: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("orders")
    .select("*")
    .eq("seller_name", sellerName)
    .eq("store", store)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar ordens da vendedora:", error)
    return []
  }

  return data
}

export async function getOrdersByStore(store: string, statuses: string[]) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("orders")
    .select("*")
    .eq("store", store)
    .in("status", statuses)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar ordens da loja:", error)
    return []
  }

  return data
}

export async function createOrder(order: any) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("orders")
    .insert([
      {
        seller_id: order.sellerId,
        seller_name: order.seller,
        store: order.store,
        client_id: order.clientId,
        client_name: order.clientName,
        amount_usd: order.amountUSD,
        amount_brl: order.amountBRL,
        payment_code: order.paymentCode,
        wallet: order.wallet,
        notes: order.notes,
        status: order.status,
        status_text: order.statusText,
      },
    ])
    .select()

  if (error) {
    console.error("Erro ao criar ordem:", error)
    return null
  }

  return data[0]
}

export async function updateOrderStatus(id: string, status: string, statusText: string, txid?: string) {
  const supabase = createClient()

  const updateData: any = {
    status,
    status_text: statusText,
    updated_at: new Date().toISOString(),
  }

  if (txid) {
    updateData.txid = txid
  }

  const { data, error } = await supabase.from("orders").update(updateData).eq("id", id).select()

  if (error) {
    console.error("Erro ao atualizar status da ordem:", error)
    return null
  }

  return data[0]
}

export async function deleteOrder(id: string) {
  const supabase = createClient()

  const { error } = await supabase.from("orders").delete().eq("id", id)

  if (error) {
    console.error("Erro ao excluir ordem:", error)
    return false
  }

  return true
}
