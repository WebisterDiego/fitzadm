"use server"

import { createClient } from "@/utils/supabase/server"

export async function getAllSellers() {
  const supabase = createClient()

  const { data, error } = await supabase.from("sellers").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Erro ao buscar vendedoras:", error)
    return []
  }

  return data
}

export async function getSellerById(id: string) {
  const supabase = createClient()

  const { data, error } = await supabase.from("sellers").select("*").eq("id", id).single()

  if (error) {
    console.error("Erro ao buscar vendedora:", error)
    return null
  }

  return data
}

export async function createSeller(seller: { name: string; store: string }) {
  const supabase = createClient()

  // Verificar se a loja já existe no financeiro
  const { data: existingFinance } = await supabase.from("finances").select("*").eq("store", seller.store).single()

  // Se a loja não existir, criar um novo painel financeiro
  if (!existingFinance) {
    await supabase.from("finances").insert([{ store: seller.store }])
  }

  // Criar vendedora
  const { data, error } = await supabase.from("sellers").insert([seller]).select()

  if (error) {
    console.error("Erro ao criar vendedora:", error)
    return null
  }

  return data[0]
}
