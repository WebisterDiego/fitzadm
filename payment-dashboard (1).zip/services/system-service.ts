"use server"

import { createClient } from "@/utils/supabase/server"

export async function fixExpiredOrders() {
  const supabase = createClient()

  try {
    const now = new Date().toISOString()

    // Atualizar ordens expiradas
    const { data, error } = await supabase
      .from("orders")
      .update({
        status: "expired",
        status_text: "Pagamento Expirado",
        updated_at: now,
      })
      .eq("status", "pending")
      .lt("expiration_time", now)
      .select()

    if (error) {
      return {
        success: false,
        message: `Erro ao atualizar ordens expiradas: ${error.message}`,
      }
    }

    return {
      success: true,
      message: `${data.length} ordens atualizadas para expiradas com sucesso`,
    }
  } catch (error) {
    console.error("Erro ao corrigir ordens expiradas:", error)
    return {
      success: false,
      message: `Erro ao corrigir ordens expiradas: ${(error as Error).message}`,
    }
  }
}

export async function checkDatabaseHealth() {
  const supabase = createClient()

  try {
    // Verificar se consegue conectar e fazer uma consulta simples
    const { data, error } = await supabase.from("orders").select("count(*)", { count: "exact" }).limit(1)

    if (error) {
      return {
        success: false,
        message: `Erro na conexão com o banco de dados: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "Conexão com o banco de dados estabelecida com sucesso",
    }
  } catch (error) {
    console.error("Erro ao verificar saúde do banco de dados:", error)
    return {
      success: false,
      message: `Erro ao verificar saúde do banco de dados: ${(error as Error).message}`,
    }
  }
}

export async function getSystemStats() {
  const supabase = createClient()

  try {
    // Obter estatísticas do sistema
    const { data: orders, error: ordersError } = await supabase.from("orders").select("id, status, created_at")

    if (ordersError) {
      throw ordersError
    }

    const { data: sellers, error: sellersError } = await supabase.from("sellers").select("id")

    if (sellersError) {
      throw sellersError
    }

    const { data: requests, error: requestsError } = await supabase.from("order_requests").select("id, seen")

    if (requestsError) {
      throw requestsError
    }

    // Calcular estatísticas
    const totalOrders = orders.length
    const pendingOrders = orders.filter((o) => o.status === "pending").length
    const completedOrders = orders.filter((o) => o.status === "released").length
    const expiredOrders = orders.filter((o) => o.status === "expired").length

    const totalSellers = sellers.length
    const totalRequests = requests.length
    const unseenRequests = requests.filter((r) => !r.seen).length

    // Calcular ordens por dia nos últimos 7 dias
    const now = new Date()
    const sevenDaysAgo = new Date(now)
    sevenDaysAgo.setDate(now.getDate() - 7)

    const last7DaysOrders = orders.filter((o) => new Date(o.created_at) >= sevenDaysAgo)

    const ordersByDay = Array(7).fill(0)
    last7DaysOrders.forEach((order) => {
      const orderDate = new Date(order.created_at)
      const dayDiff = Math.floor((now.getTime() - orderDate.getTime()) / (1000 * 60 * 60 * 24))
      if (dayDiff >= 0 && dayDiff < 7) {
        ordersByDay[dayDiff]++
      }
    })

    return {
      success: true,
      stats: {
        orders: {
          total: totalOrders,
          pending: pendingOrders,
          completed: completedOrders,
          expired: expiredOrders,
        },
        sellers: {
          total: totalSellers,
        },
        requests: {
          total: totalRequests,
          unseen: unseenRequests,
        },
        ordersByDay: ordersByDay.reverse(), // Do mais antigo para o mais recente
      },
    }
  } catch (error) {
    console.error("Erro ao obter estatísticas do sistema:", error)
    return {
      success: false,
      message: `Erro ao obter estatísticas do sistema: ${(error as Error).message}`,
    }
  }
}
