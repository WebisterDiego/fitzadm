import { createClient } from "@/utils/supabase/server"

export interface ValidationResult {
  success: boolean
  message: string
  details?: any
}

export async function validateDatabaseStructure(): Promise<ValidationResult> {
  const supabase = createClient()

  try {
    // Verificar se todas as tabelas necessárias existem
    const requiredTables = ["orders", "order_requests", "sellers", "finances", "security_settings"]
    const { data: tables, error: tablesError } = await supabase
      .from("information_schema.tables")
      .select("table_name")
      .eq("table_schema", "public")

    if (tablesError) {
      return {
        success: false,
        message: "Erro ao verificar tabelas do banco de dados",
        details: tablesError,
      }
    }

    const existingTables = tables.map((t) => t.table_name)
    const missingTables = requiredTables.filter((t) => !existingTables.includes(t))

    if (missingTables.length > 0) {
      return {
        success: false,
        message: `Tabelas ausentes no banco de dados: ${missingTables.join(", ")}`,
        details: { missingTables },
      }
    }

    // Verificar campos obrigatórios na tabela orders
    const requiredOrderFields = [
      "id",
      "created_at",
      "updated_at",
      "seller_id",
      "seller_name",
      "store",
      "client_id",
      "client_name",
      "amount_usd",
      "amount_brl",
      "status",
      "status_text",
      "payment_code",
      "expiration_time",
    ]

    const { data: orderColumns, error: orderColumnsError } = await supabase
      .from("information_schema.columns")
      .select("column_name")
      .eq("table_schema", "public")
      .eq("table_name", "orders")

    if (orderColumnsError) {
      return {
        success: false,
        message: "Erro ao verificar campos da tabela orders",
        details: orderColumnsError,
      }
    }

    const existingOrderColumns = orderColumns.map((c) => c.column_name)
    const missingOrderColumns = requiredOrderFields.filter((f) => !existingOrderColumns.includes(f))

    if (missingOrderColumns.length > 0) {
      return {
        success: false,
        message: `Campos ausentes na tabela orders: ${missingOrderColumns.join(", ")}`,
        details: { missingOrderColumns },
      }
    }

    // Verificar índices importantes
    const { data: indices, error: indicesError } = await supabase
      .from("pg_indexes")
      .select("indexname, indexdef")
      .eq("schemaname", "public")
      .eq("tablename", "orders")

    if (indicesError) {
      return {
        success: false,
        message: "Erro ao verificar índices",
        details: indicesError,
      }
    }

    const hasExpirationIndex = indices.some(
      (idx) => idx.indexname.includes("expiration_time") || idx.indexdef.includes("expiration_time"),
    )

    if (!hasExpirationIndex) {
      return {
        success: false,
        message: "Índice para o campo expiration_time não encontrado",
        details: { recommendation: "Adicione um índice para otimizar consultas de expiração" },
      }
    }

    return {
      success: true,
      message: "Estrutura do banco de dados validada com sucesso",
    }
  } catch (error) {
    return {
      success: false,
      message: "Erro ao validar estrutura do banco de dados",
      details: error,
    }
  }
}

export async function checkExpiredOrders(): Promise<ValidationResult> {
  const supabase = createClient()

  try {
    const now = new Date().toISOString()

    // Verificar ordens que deveriam estar expiradas
    const { data, error } = await supabase
      .from("orders")
      .select("id")
      .eq("status", "pending")
      .lt("expiration_time", now)

    if (error) {
      return {
        success: false,
        message: "Erro ao verificar ordens expiradas",
        details: error,
      }
    }

    if (data && data.length > 0) {
      return {
        success: false,
        message: `Encontradas ${data.length} ordens que deveriam estar expiradas`,
        details: { count: data.length, orderIds: data.map((o) => o.id) },
      }
    }

    return {
      success: true,
      message: "Nenhuma ordem expirada encontrada",
    }
  } catch (error) {
    return {
      success: false,
      message: "Erro ao verificar ordens expiradas",
      details: error,
    }
  }
}
