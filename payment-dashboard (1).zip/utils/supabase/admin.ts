import { createClient } from "@supabase/supabase-js"

// Cria um cliente Supabase com a chave de serviço para operações administrativas
export const createAdminClient = () => {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL || "", process.env.SUPABASE_SERVICE_ROLE_KEY || "")
}
